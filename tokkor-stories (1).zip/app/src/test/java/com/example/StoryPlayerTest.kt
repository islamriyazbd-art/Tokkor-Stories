package com.example

import android.content.Context
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.SemanticsMatcher
import androidx.compose.ui.test.assert
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.unit.LayoutDirection
import androidx.media3.common.Player
import androidx.test.core.app.ApplicationProvider
import com.example.data.StoryRepository
import com.example.model.PlaybackStatus
import com.example.model.PlaybackUiState
import com.example.model.StoryLanguage
import com.example.model.SupportedStoryLanguages
import com.example.model.VoiceGenderPreference
import com.example.model.VoicePlaybackStatus
import com.example.model.VoiceUiState
import com.example.player.AndroidTtsVoiceController
import com.example.player.ExoPlayerStoryController
import com.example.player.StoryPlayerController
import com.example.player.StoryVoiceController
import com.example.ui.StoriesViewModel
import com.example.ui.theme.TokkorStoriesTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

private class FakeStoryPlayerController : StoryPlayerController {
  override val player: Player? = null

  private val _playbackState = MutableStateFlow(PlaybackUiState())
  override val playbackState: StateFlow<PlaybackUiState> = _playbackState.asStateFlow()

  val loadedUrls = mutableListOf<String>()
  var retryCount = 0
    private set

  var isDucked = false
    private set

  override fun loadStory(url: String, autoPlay: Boolean) {
    loadedUrls.add(url)
    _playbackState.value =
      PlaybackUiState(
        status = PlaybackStatus.BUFFERING,
        isPlaying = false,
        isMuted = _playbackState.value.isMuted,
        positionMs = 0L,
        durationMs = 15_000L,
        errorMessage = null,
      )
  }

  fun emitReady(isPlaying: Boolean = true, durationMs: Long = 15_000L) {
    _playbackState.update {
      it.copy(
        status = PlaybackStatus.READY,
        isPlaying = isPlaying,
        durationMs = durationMs,
        errorMessage = null,
      )
    }
  }

  fun emitError(message: String = "Network connection lost.") {
    _playbackState.update {
      it.copy(
        status = PlaybackStatus.ERROR,
        isPlaying = false,
        errorMessage = message,
      )
    }
  }

  override fun play() {
    _playbackState.update { it.copy(status = PlaybackStatus.READY, isPlaying = true) }
  }

  override fun pause() {
    _playbackState.update { it.copy(status = PlaybackStatus.READY, isPlaying = false) }
  }

  override fun togglePlayPause() {
    if (_playbackState.value.isPlaying) pause() else play()
  }

  override fun seekTo(positionMs: Long) {
    _playbackState.update { it.copy(positionMs = positionMs) }
  }

  override fun setMuted(muted: Boolean) {
    _playbackState.update { it.copy(isMuted = muted) }
  }

  override fun setAudioDucked(ducked: Boolean) {
    isDucked = ducked
  }

  override fun toggleMute() {
    setMuted(!_playbackState.value.isMuted)
  }

  override fun retry() {
    retryCount++
    loadedUrls.lastOrNull()?.let { loadStory(it, autoPlay = true) }
  }

  override fun stop() {
    _playbackState.value = PlaybackUiState(isMuted = _playbackState.value.isMuted)
  }

  override fun release() = Unit
}

private class FakeStoryVoiceController : StoryVoiceController {
  private val _voiceState =
    MutableStateFlow(
      VoiceUiState(
        isEngineReady = true,
        supportsFemaleVoice = true,
        supportsMaleVoice = true,
        activeVoiceLabel = "English • Natural",
      )
    )
  override val voiceState: StateFlow<VoiceUiState> = _voiceState.asStateFlow()

  val spokenTexts = mutableListOf<String>()

  override fun setLanguage(language: StoryLanguage) {
    _voiceState.update {
      it.copy(
        selectedLanguage = language,
        activeVoiceLabel = "${language.englishName} • ${it.genderPreference.name}",
        status =
          if (language.isDeviceSupported) {
            VoicePlaybackStatus.IDLE
          } else {
            VoicePlaybackStatus.UNSUPPORTED
          },
        statusMessage =
          if (language.isDeviceSupported) {
            null
          } else {
            "Voice data for ${language.displayLabel} is not installed on this device."
          },
      )
    }
  }

  override fun setGenderPreference(gender: VoiceGenderPreference) {
    _voiceState.update {
      it.copy(
        genderPreference = gender,
        activeVoiceLabel = "${it.selectedLanguage.englishName} • ${gender.name}",
      )
    }
  }

  override fun setSpeed(speed: Float) {
    _voiceState.update { it.copy(speed = speed.coerceIn(0.5f, 2.0f)) }
  }

  override fun speak(text: String) {
    if (!_voiceState.value.selectedLanguage.isDeviceSupported) {
      _voiceState.update {
        it.copy(
          status = VoicePlaybackStatus.UNSUPPORTED,
          statusMessage = "Voice data not installed.",
        )
      }
      return
    }
    spokenTexts.add(text)
    _voiceState.update {
      it.copy(
        status = VoicePlaybackStatus.SPEAKING,
        currentSegmentIndex = 0,
        totalSegments = AndroidTtsVoiceController.splitNarrationSegments(text).size,
      )
    }
  }

  override fun pause() {
    if (_voiceState.value.status == VoicePlaybackStatus.SPEAKING) {
      _voiceState.update { it.copy(status = VoicePlaybackStatus.PAUSED) }
    }
  }

  override fun resume() {
    if (_voiceState.value.status == VoicePlaybackStatus.PAUSED) {
      _voiceState.update { it.copy(status = VoicePlaybackStatus.SPEAKING) }
    }
  }

  override fun togglePlayPause(text: String) {
    when (_voiceState.value.status) {
      VoicePlaybackStatus.SPEAKING -> pause()
      VoicePlaybackStatus.PAUSED -> resume()
      else -> speak(text)
    }
  }

  override fun stop() {
    _voiceState.update {
      it.copy(
        status =
          if (it.status == VoicePlaybackStatus.UNSUPPORTED) {
            VoicePlaybackStatus.UNSUPPORTED
          } else {
            VoicePlaybackStatus.IDLE
          },
        currentSegmentIndex = 0,
      )
    }
  }

  override fun release() = Unit
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StoryPlayerTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun allRepositoryStoriesHaveValidPlayableHttpsVideoUrlsAndTranslations() {
    val stories = StoryRepository.getStories()
    val requiredLanguages = listOf("bn", "en", "ar", "hi", "zh", "ru")
    assertTrue("Expected non-empty stories list", stories.isNotEmpty())
    stories.forEach { story ->
      assertTrue("Story ${story.id} must have valid HTTPS URL", story.videoUrl.startsWith("https://"))
      assertTrue("Story ${story.id} must point to valid video asset", story.videoUrl.endsWith(".mp4"))
      assertTrue("Story ${story.id} must have non-blank title", story.title.isNotBlank())
      requiredLanguages.forEach { code ->
        assertTrue(
          "Story ${story.id} missing translation for $code",
          story.localizedContent.containsKey(code),
        )
        assertTrue(
          "Story ${story.id} narration blank for $code",
          story.localizedNarration(code).isNotBlank(),
        )
      }
    }
  }

  @Test
  fun openingAnyStoryLaunchesFullscreenPlayerWithBufferingThenPlayPauseControls() {
    val fakePlayer = FakeStoryPlayerController()
    val fakeVoice = FakeStoryVoiceController()
    val stories = StoryRepository.getStories()
    val viewModel = StoriesViewModel(fakePlayer, stories, fakeVoice)

    composeTestRule.setContent {
      TokkorStoriesTheme {
        TokkorStoriesApp(viewModel = viewModel)
      }
    }

    composeTestRule.onNodeWithTag("story_ring_${stories[1].id}").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("fullscreen_story_player").assertIsDisplayed()
    composeTestRule.onNodeWithTag("video_loading_indicator").assertIsDisplayed()
    composeTestRule.onNodeWithTag("story_counter_text").assertTextEquals("2 / ${stories.size}")
    assertEquals(stories[1].videoUrl, fakePlayer.loadedUrls.last())

    composeTestRule.runOnUiThread { fakePlayer.emitReady(isPlaying = true) }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("video_loading_indicator").assertDoesNotExist()

    composeTestRule.onNodeWithTag("play_pause_button").performClick()
    composeTestRule.waitForIdle()
    assertFalse(viewModel.uiState.value.playbackState.isPlaying)
    composeTestRule.onNodeWithTag("center_play_pause_indicator").assertIsDisplayed()

    composeTestRule.onNodeWithTag("play_pause_button").performClick()
    composeTestRule.waitForIdle()
    assertTrue(viewModel.uiState.value.playbackState.isPlaying)
  }

  @Test
  fun nextAndPreviousNavigationWorksAndRespectsBoundaries() {
    val fakePlayer = FakeStoryPlayerController()
    val fakeVoice = FakeStoryVoiceController()
    val stories = StoryRepository.getStories()
    val viewModel = StoriesViewModel(fakePlayer, stories, fakeVoice)

    composeTestRule.setContent {
      TokkorStoriesTheme {
        TokkorStoriesApp(viewModel = viewModel)
      }
    }

    composeTestRule.onNodeWithTag("watch_stories_button").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("story_counter_text").assertTextEquals("1 / ${stories.size}")
    composeTestRule.onNodeWithTag("previous_video_button").assertIsNotEnabled()
    composeTestRule.onNodeWithTag("next_video_button").assertIsEnabled()

    composeTestRule.onNodeWithTag("next_video_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("story_counter_text").assertTextEquals("2 / ${stories.size}")
    assertEquals(stories[1].videoUrl, fakePlayer.loadedUrls.last())
    composeTestRule.onNodeWithTag("previous_video_button").assertIsEnabled()

    composeTestRule.onNodeWithTag("controls_previous_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("story_counter_text").assertTextEquals("1 / ${stories.size}")
    assertEquals(stories[0].videoUrl, fakePlayer.loadedUrls.last())
  }

  @Test
  fun videoErrorShowsErrorOverlayAndSupportsRetryAndSkipNext() {
    val fakePlayer = FakeStoryPlayerController()
    val fakeVoice = FakeStoryVoiceController()
    val stories = StoryRepository.getStories()
    val viewModel = StoriesViewModel(fakePlayer, stories, fakeVoice)

    composeTestRule.setContent {
      TokkorStoriesTheme {
        TokkorStoriesApp(viewModel = viewModel)
      }
    }

    composeTestRule.onNodeWithTag("watch_stories_button").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.runOnUiThread { fakePlayer.emitError("Network timeout") }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("video_error_overlay").assertIsDisplayed()

    composeTestRule.onNodeWithTag("retry_video_button").performClick()
    composeTestRule.waitForIdle()
    assertEquals(1, fakePlayer.retryCount)
    composeTestRule.onNodeWithTag("video_error_overlay").assertDoesNotExist()
    composeTestRule.onNodeWithTag("video_loading_indicator").assertIsDisplayed()

    composeTestRule.runOnUiThread { fakePlayer.emitError("Stream unreachable") }
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("error_next_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("story_counter_text").assertTextEquals("2 / ${stories.size}")
  }

  @Test
  fun multilingualLanguageSelectionRtlArabicAndVoiceControlsWorkTogether() {
    val fakePlayer = FakeStoryPlayerController()
    val fakeVoice = FakeStoryVoiceController()
    val stories = StoryRepository.getStories()
    val viewModel = StoriesViewModel(fakePlayer, stories, fakeVoice)

    composeTestRule.setContent {
      TokkorStoriesTheme {
        TokkorStoriesApp(viewModel = viewModel)
      }
    }

    // Open Language & Voice Studio from home screen
    composeTestRule.onNodeWithTag("language_selector_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("language_voice_sheet").assertIsDisplayed()

    // Select Arabic, Male voice, and 1.5x speed
    composeTestRule.onNodeWithTag("language_option_ar").performScrollTo().performClick()
    composeTestRule.onNodeWithTag("voice_gender_male").performScrollTo().performClick()
    composeTestRule.onNodeWithTag("voice_speed_1.5").performScrollTo().performClick()
    composeTestRule.waitForIdle()

    assertEquals("ar", viewModel.uiState.value.selectedLanguage.code)
    assertEquals(VoiceGenderPreference.MALE, viewModel.uiState.value.voiceState.genderPreference)
    assertEquals(1.5f, viewModel.uiState.value.voiceState.speed, 0.01f)

    // Close sheet and verify Home clearly shows Arabic
    composeTestRule.onNodeWithTag("close_language_sheet_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule
      .onNodeWithTag("home_selected_language_text", useUnmergedTree = true)
      .assertTextContains("Arabic", substring = true)

    // Launch player and verify Arabic RTL layout & voice play/pause/resume
    composeTestRule.onNodeWithTag("watch_stories_button").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("player_language_chip").assertIsDisplayed()
    assertEquals(
      LayoutDirection.Rtl,
      composeTestRule
        .onNodeWithTag("narration_localized_text")
        .fetchSemanticsNode()
        .layoutInfo
        .layoutDirection,
    )

    // Play -> Pause -> Resume TTS narration
    composeTestRule.onNodeWithTag("voice_play_pause_button").performClick()
    composeTestRule.waitForIdle()
    assertEquals(VoicePlaybackStatus.SPEAKING, viewModel.uiState.value.voiceState.status)
    assertTrue(fakePlayer.isDucked)
    assertEquals(stories[0].localizedNarration("ar"), fakeVoice.spokenTexts.last())

    composeTestRule.onNodeWithTag("voice_play_pause_button").performClick()
    composeTestRule.waitForIdle()
    assertEquals(VoicePlaybackStatus.PAUSED, viewModel.uiState.value.voiceState.status)
    assertFalse(fakePlayer.isDucked)

    composeTestRule.onNodeWithTag("voice_play_pause_button").performClick()
    composeTestRule.waitForIdle()
    assertEquals(VoicePlaybackStatus.SPEAKING, viewModel.uiState.value.voiceState.status)

    // Switch to Bengali and verify narration updates cleanly
    composeTestRule.runOnUiThread {
      viewModel.selectLanguage(SupportedStoryLanguages.Bengali)
    }
    composeTestRule.waitForIdle()
    assertEquals("bn", viewModel.uiState.value.selectedLanguage.code)
    assertEquals(stories[0].localizedNarration("bn"), fakeVoice.spokenTexts.last())
  }

  @Test
  fun unsupportedLanguageHandledGracefullyWithoutBreakingVideoPlayback() {
    val fakePlayer = FakeStoryPlayerController()
    val fakeVoice = FakeStoryVoiceController()
    val stories = StoryRepository.getStories()
    val viewModel = StoriesViewModel(fakePlayer, stories, fakeVoice)

    composeTestRule.setContent {
      TokkorStoriesTheme {
        TokkorStoriesApp(viewModel = viewModel)
      }
    }

    val unsupportedLang =
      StoryLanguage(
        code = "bn",
        languageTag = "bn-BD",
        englishName = "Bengali",
        nativeName = "বাংলা",
        flagBadge = "BN",
        isDeviceSupported = false,
      )

    composeTestRule.runOnUiThread {
      viewModel.selectLanguage(unsupportedLang)
      viewModel.openAllStoriesFromStart()
      fakePlayer.emitReady(isPlaying = true)
    }
    composeTestRule.waitForIdle()

    // Graceful warning shown, video playback still active
    composeTestRule.onNodeWithTag("player_voice_unsupported_badge").assertIsDisplayed()
    assertTrue(viewModel.uiState.value.playbackState.isPlaying)
  }

  @Test
  fun ttsNarrationSegmentationHandlesMultilingualPunctuationAndControllerReleasesCleanly() {
    val bengaliSegments =
      AndroidTtsVoiceController.splitNarrationSegments("প্রথম বাক্য। দ্বিতীয় বাক্য! তৃতীয়?")
    assertEquals(3, bengaliSegments.size)

    val chineseSegments =
      AndroidTtsVoiceController.splitNarrationSegments("第一句话。第二句话！")
    assertEquals(2, chineseSegments.size)

    val context = ApplicationProvider.getApplicationContext<Context>()
    val ttsController = AndroidTtsVoiceController(context)
    ttsController.setSpeed(1.25f)
    ttsController.setLanguage(SupportedStoryLanguages.Arabic)
    ttsController.release()

    val exoController = ExoPlayerStoryController(context)
    try {
      exoController.loadStory("")
      assertEquals(PlaybackStatus.ERROR, exoController.playbackState.value.status)
    } finally {
      exoController.release()
    }
  }
}

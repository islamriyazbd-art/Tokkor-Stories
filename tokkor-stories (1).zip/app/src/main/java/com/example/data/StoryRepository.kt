package com.example.data

import com.example.R
import com.example.model.LocalizedStoryContent
import com.example.model.Story

object StoryRepository {

  fun getStories(): List<Story> =
    listOf(
      Story(
        id = "story_1",
        title = "Midnight Neon Drift",
        creatorName = "Kenji Sato",
        creatorHandle = "@kenji.reels",
        category = "Urban",
        durationLabel = "0:15",
        videoUrl =
          "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4",
        posterResId = R.drawable.img_story_poster_neon,
        likesCount = 1240,
        description = "Late-night city lights and high-contrast reflections through Shibuya.",
        localizedContent =
          mapOf(
            "en" to
              LocalizedStoryContent(
                title = "Midnight Neon Drift",
                description = "Late-night city lights and high-contrast reflections through Shibuya.",
                narrationScript =
                  "Midnight falls over the neon avenue. Rain-slicked streets mirror glowing amber and violet signs. Every corner reveals a quiet cinematic pulse in the heart of the city.",
              ),
            "bn" to
              LocalizedStoryContent(
                title = "মধ্যরাতের নিয়ন গল্প",
                description = "বৃষ্টির পর শহরের উজ্জ্বল নিয়ন আলো আর রাতের মায়াবী প্রতিফলন।",
                narrationScript =
                  "মধ্যরাতে শহরের রাস্তায় নিয়ন আলো জ্বলে উঠেছে। বৃষ্টির ভেজা পথে সোনালি ও বেগুনি রঙের প্রতিফলন ভেসে বেড়াচ্ছে। প্রতিটি মোড়ে লুকিয়ে আছে রাতের শহরের এক শান্ত সিনেম্যাটিক ছন্দ।",
              ),
            "ar" to
              LocalizedStoryContent(
                title = "انجراف النيون في منتصف الليل",
                description = "أضواء المدينة الليلية وانعكاسات الألوان الدافئة بعد المطر.",
                narrationScript =
                  "يهبط منتصف الليل فوق شارع النيون المتلألئ. تعكس الطرق المبتلة أضواء العنبر والبنفسج الساحرة. في كل زاوية ينبض إيقاع سينمائي هادئ في قلب المدينة.",
              ),
            "hi" to
              LocalizedStoryContent(
                title = "मिडनाइट नियॉन ड्रिफ्ट",
                description = "बारिश के बाद रात की चमकती सड़कें और नियॉन रोशनी की झलक।",
                narrationScript =
                  "आधी रात को नियॉन रोशनी से सजा शहर जाग उठता है। भीगी सड़कों पर सुनहरे और बैंगनी रंग चमक रहे हैं। हर मोड़ पर शहर की एक शांत और जादुई कहानी बसती है।",
              ),
            "zh" to
              LocalizedStoryContent(
                title = "午夜霓虹漂移",
                description = "雨后深夜的城市霓虹灯光与高对比度街头倒影。",
                narrationScript =
                  "午夜降临在霓虹闪耀的大街上。雨水浸湿的路面映出琥珀色与紫罗兰的光影。城市的每一个转角都在讲述一段静谧而动人的光影故事。",
              ),
            "ru" to
              LocalizedStoryContent(
                title = "Полуночный неоновый дрифт",
                description = "Ночные огни мегаполиса и яркие отражения на мокром асфальте.",
                narrationScript =
                  "Полночь опускается на неоновый проспект. Мокрый асфальт отражает золотые и фиолетовые огни витрин. За каждым поворотом скрывается живой кинематографичный ритм ночного города.",
              ),
            "es" to
              LocalizedStoryContent(
                title = "Deriva de Neón Nocturna",
                description = "Luces urbanas nocturnas y reflejos vibrantes tras la lluvia.",
                narrationScript =
                  "La medianoche cubre la avenida iluminada por neones. El pavimento húmedo refleja destellos dorados y violetas en cada esquina de la ciudad.",
              ),
            "fr" to
              LocalizedStoryContent(
                title = "Dérive Néon de Minuit",
                description = "Lumières nocturnes de la ville et reflets dorés après la pluie.",
                narrationScript =
                  "Minuit tombe sur l'avenue illuminée de néons. Les rues mouillées reflètent des lueurs dorées et violettes au cœur de la ville.",
              ),
          ),
      ),
      Story(
        id = "story_2",
        title = "Alpine Ridge Dawn",
        creatorName = "Maya Lin",
        creatorHandle = "@maya.outdoors",
        category = "Nature",
        durationLabel = "0:15",
        videoUrl =
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        posterResId = R.drawable.img_story_poster_nature,
        likesCount = 982,
        description = "First sunlight breaking across the misty pine ridge at 6:05 AM.",
        localizedContent =
          mapOf(
            "en" to
              LocalizedStoryContent(
                title = "Alpine Ridge Dawn",
                description = "First sunlight breaking across the misty pine ridge at 6:05 AM.",
                narrationScript =
                  "High above the valley, dawn breaks through drifting silver mist. Golden sunbeams warm the ancient pine ridge. The mountain awakens in crisp, timeless silence.",
              ),
            "bn" to
              LocalizedStoryContent(
                title = "পাহাড়ি চূড়ায় ভোরের আলো",
                description = "ভোর ছয়টায় কুয়াশাচ্ছন্ন পাইন বনের ওপর প্রথম সোনালি সূর্যোদয়।",
                narrationScript =
                  "উপত্যকার অনেক ওপরে কুয়াশার চাদর ভেদ করে ভোরের আলো ফুটে উঠেছে। সোনালি রোদ প্রাচীন পাইন বনের চূড়াকে উষ্ণ করে তুলছে। পাহাড় জেগে উঠছে এক অপূর্ব নীরবতায়।",
              ),
            "ar" to
              LocalizedStoryContent(
                title = "فجر القمم الألبية",
                description = "أول خيوط الشمس الذهبية تخترق ضباب الصنوبر عند الفجر.",
                narrationScript =
                  "فوق الوادي المرتفع، ينبثق الفجر عبر الضباب الفضي المنساب. تغمر أشعة الشمس الذهبية قمم الصنوبر العتيقة. يستيقظ الجبل في سكون نقي يأسر الأنفاس.",
              ),
            "hi" to
              LocalizedStoryContent(
                title = "अल्पाइन शिखर पर भोर",
                description = "सुबह धुंध से ढकी पहाड़ी चोटियों पर पड़ती पहली सुनहरी किरणें।",
                narrationScript =
                  "घाटी से ऊपर धुंध के बीच सुनहरी भोर दस्तक दे रही है। सूरज की पहली किरणें चीड़ के पेड़ों को रोशन कर रही हैं। पूरा पर्वत शांत और मनमोहक ऊर्जा से जाग उठा है।",
              ),
            "zh" to
              LocalizedStoryContent(
                title = "高山山脊的黎明",
                description = "清晨六点第一缕金色阳光穿透薄雾照亮松林山脊。",
                narrationScript =
                  "在山谷高处，黎明穿透流动的银色薄雾。金色阳光温暖了古老的松林山脊。群山在清澈而宁静的晨光中缓缓苏醒。",
              ),
            "ru" to
              LocalizedStoryContent(
                title = "Рассвет на альпийском хребте",
                description = "Первые лучи солнца пробиваются сквозь утренний туман в горах.",
                narrationScript =
                  "Высоко над долиной рассвет рассеивает серебристый туман. Золотые лучи согревают вековые сосны на горном хребте. Горы просыпаются в кристальной утренней тишине.",
              ),
          ),
      ),
      Story(
        id = "story_3",
        title = "Pacific Swell Session",
        creatorName = "Leo Vance",
        creatorHandle = "@leovance",
        category = "Action",
        durationLabel = "1:00",
        videoUrl =
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        posterResId = R.drawable.img_story_poster_ocean,
        likesCount = 2150,
        description = "Catching clean evening rollers along the Pacific coast.",
        localizedContent =
          mapOf(
            "en" to
              LocalizedStoryContent(
                title = "Pacific Swell Session",
                description = "Catching clean evening rollers along the Pacific coast.",
                narrationScript =
                  "Turquoise swells rise cleanly beneath a coral sunset sky. Every wave carries momentum from across the open Pacific. Timing, balance, and ocean rhythm come together in motion.",
              ),
            "bn" to
              LocalizedStoryContent(
                title = "প্রশান্ত মহাসাগরের ঢেউ",
                description = "সন্ধ্যার রাঙা আকাশের নিচে প্রশান্ত মহাসাগরের স্বচ্ছ ঢেউয়ের অভিযান।",
                narrationScript =
                  "সন্ধ্যার রঙিন আকাশের নিচে ফিরোজা রঙের বিশাল ঢেউ জেগে উঠছে। প্রতিটি ঢেউ নিয়ে আসছে গভীর সমুদ্রের অফুরন্ত গতি। ভারসাম্য আর ছন্দে সাগরের বুকে রচিত হচ্ছে রোমাঞ্চকর গল্প।",
              ),
            "ar" to
              LocalizedStoryContent(
                title = "موجة المحيط الهادئ",
                description = "ركوب الأمواج الفيروزية تحت ألوان الغروب الدافئة.",
                narrationScript =
                  "ترتفع الأمواج الفيروزية بنقاء تحت سماء الغروب المرجانية. تحمل كل موجة طاقة المحيط الواسع. هنا يلتقي التوازن والإيقاع في حركة ساحرة.",
              ),
            "hi" to
              LocalizedStoryContent(
                title = "प्रशांत महासागर की लहरें",
                description = "सूर्यास्त के सुनहरे रंगों के बीच समुद्र की ऊंची लहरों का रोमांच।",
                narrationScript =
                  "सुनहरे सूर्यास्त के नीचे नीली समुद्री लहरें ऊंची उठ रही हैं। हर लहर में खुले महासागर की अद्भुत गति समाई है। संतुलन और लय मिलकर एक जीवंत कहानी बुनते हैं।",
              ),
            "zh" to
              LocalizedStoryContent(
                title = "太平洋浪涌时刻",
                description = "夕阳映照下在太平洋海岸追逐清澈海浪。",
                narrationScript =
                  "碧蓝的海浪在珊瑚色晚霞下优雅涌起。每一道浪潮都带着辽阔太平洋的能量。精准的节奏与平衡在海面上跃动展开。",
              ),
            "ru" to
              LocalizedStoryContent(
                title = "Сессия на волнах Тихого океана",
                description = "Вечерние океанские волны на фоне яркого заката.",
                narrationScript =
                  "Бирюзовые волны плавно поднимаются под закатным небом. Каждая волна несет в себе мощь бескрайнего океана. Баланс и ритм сливаются в чистом движении.",
              ),
          ),
      ),
      Story(
        id = "story_4",
        title = "Golden Hour Alley",
        creatorName = "Nadia Karim",
        creatorHandle = "@nadiakarim",
        category = "Urban",
        durationLabel = "0:15",
        videoUrl =
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoy.mp4",
        posterResId = R.drawable.img_story_poster_neon,
        likesCount = 874,
        description = "Warm street colors and quick cuts from the evening market.",
        localizedContent =
          mapOf(
            "en" to
              LocalizedStoryContent(
                title = "Golden Hour Alley",
                description = "Warm street colors and quick cuts from the evening market.",
                narrationScript =
                  "Lanterns flicker to life as golden hour fades into dusk. Voices, spices, and music weave through the narrow lane. Every frame celebrates vibrant everyday storytelling.",
              ),
            "bn" to
              LocalizedStoryContent(
                title = "সোনালি সন্ধ্যার গলি",
                description = "সন্ধ্যার বাজারের উষ্ণ আলো, রঙ আর প্রাণবন্ত মানুষের গল্প।",
                narrationScript =
                  "গোধূলির আলো মিলিয়ে যেতেই গলির লণ্ঠনগুলো জ্বলে উঠল। মানুষের হাসি, সুর আর রঙিন আলোয় ভরে উঠেছে সন্ধ্যা। প্রতিটি মুহূর্ত যেন জীবন্ত এক ছোটগল্প।",
              ),
            "ar" to
              LocalizedStoryContent(
                title = "زقاق الساعة الذهبية",
                description = "ألوان الشارع الدافئة وأجواء السوق المسائي النابض بالحياة.",
                narrationScript =
                  "تتوهج الفوانيس مع تلاشي ضوء الساعة الذهبية نحو الغسق. تتعانق الأصوات والموسيقى في الممر الحيوي. كل لقطة تحتفي بجمال القصص اليومية.",
              ),
            "hi" to
              LocalizedStoryContent(
                title = "सुनहरी शाम की गली",
                description = "शाम के बाज़ार के गरम रंग और चहल-पहल भरी दास्तान।",
                narrationScript =
                  "ढलती शाम के साथ गलियों के लालटेन चमकने लगते हैं। संगीत और रौनक से पूरा माहौल जीवंत हो उठता है। हर दृश्य रोज़मर्रा की खूबसूरत कहानी कहता है।",
              ),
            "zh" to
              LocalizedStoryContent(
                title = "黄金时刻小巷",
                description = "黄昏集市里的温暖街景与生动的剪影故事。",
                narrationScript =
                  "暮色降临时，小巷里的灯笼逐一亮起。欢声笑语与音乐交织在温暖的夜风中。每一帧画面都充满鲜活的城市故事。",
              ),
            "ru" to
              LocalizedStoryContent(
                title = "Переулок золотого часа",
                description = "Теплые краски вечернего рынка и динамичный монтаж.",
                narrationScript =
                  "Фонари вспыхивают, когда золотой час сменяется сумерками. Голоса и музыка наполняют уютный переулок. Каждый кадр передает живую атмосферу города.",
              ),
          ),
      ),
      Story(
        id = "story_5",
        title = "Backcountry Trail Run",
        creatorName = "Samira Patel",
        creatorHandle = "@samira.trail",
        category = "Nature",
        durationLabel = "0:59",
        videoUrl =
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
        posterResId = R.drawable.img_story_poster_nature,
        likesCount = 1615,
        description = "From paved switchbacks to dusty canyon ridge trails.",
        localizedContent =
          mapOf(
            "en" to
              LocalizedStoryContent(
                title = "Backcountry Trail Run",
                description = "From paved switchbacks to dusty canyon ridge trails.",
                narrationScript =
                  "Leaving smooth pavement behind, the trail climbs into wild canyon terrain. Dust rises behind each turn beneath wide open skies. Adventure begins where the city road ends.",
              ),
            "bn" to
              LocalizedStoryContent(
                title = "গিরিপথের রোমাঞ্চকর যাত্রা",
                description = "পিচঢালা পথ পেরিয়ে ধুলোময় গিরিখাতের বুনো পথে অভিযান।",
                narrationScript =
                  "শহরের মসৃণ রাস্তা পেছনে ফেলে পথ এগিয়ে চলেছে গিরিখাতের দিকে। খোলা আকাশের নিচে প্রতিটি বাঁকে উড়ছে ধুলোর মেঘ। যেখানে পাকা রাস্তা শেষ, সেখান থেকেই শুরু হয় আসল অভিযান।",
              ),
            "ar" to
              LocalizedStoryContent(
                title = "مغامرة درب الوادي",
                description = "من المنعطفات المعبدة إلى المسارات الجبلية الوعرة.",
                narrationScript =
                  "بعيداً عن الطرق المعبدة، يصعد الدرب نحو تضاريس الوادي البرية. يرتفع الغبار خلف كل منعطف تحت سماء مفتوحة. تبدأ المغامرة الحقيقية حيث ينتهي الطريق.",
              ),
            "hi" to
              LocalizedStoryContent(
                title = "पहाड़ी ट्रेल का सफ़र",
                description = "पक्की सड़कों से निकलकर घाटी के रोमांचक रास्तों की ओर।",
                narrationScript =
                  "शहर की सड़कों को पीछे छोड़कर यह रास्ता पहाड़ी घाटियों की ओर बढ़ता है। खुले आसमान के नीचे हर मोड़ पर नया रोमांच इंतज़ार कर रहा है।",
              ),
            "zh" to
              LocalizedStoryContent(
                title = "荒野峡谷穿越",
                description = "从盘山公路驶向尘土飞扬的峡谷山脊小径。",
                narrationScript =
                  "离开平坦的公路，旅程深入壮阔的峡谷山野。尘土在开阔的天空下飞扬。真正的冒险，从公路尽头开始。",
              ),
            "ru" to
              LocalizedStoryContent(
                title = "Заезд по горной тропе",
                description = "От серпантина к пыльным тропам каньона.",
                narrationScript =
                  "Оставив ровный асфальт позади, маршрут уходит в дикие каньоны. На каждом повороте поднимается пыль под бескрайним небом. Приключение начинается там, где заканчивается дорога.",
              ),
          ),
      ),
      Story(
        id = "story_6",
        title = "Coastal Highway Run",
        creatorName = "Tariq Noor",
        creatorHandle = "@tariqnoor",
        category = "Action",
        durationLabel = "0:47",
        videoUrl =
          "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
        posterResId = R.drawable.img_story_poster_ocean,
        likesCount = 3090,
        description = "High-speed convoy run along open coastal roads at dusk.",
        localizedContent =
          mapOf(
            "en" to
              LocalizedStoryContent(
                title = "Coastal Highway Run",
                description = "High-speed convoy run along open coastal roads at dusk.",
                narrationScript =
                  "Engines hum along the sweeping coastal highway as twilight paints the horizon. Ocean breeze meets open-road momentum. This is the finale of today's global story reel.",
              ),
            "bn" to
              LocalizedStoryContent(
                title = "উপকূলীয় মহাসড়কের গতি",
                description = "গোধূলি বেলায় সমুদ্রতীরের খোলা মহাসড়ক ধরে দ্রুতগতির যাত্রা।",
                narrationScript =
                  "গোধূলির রঙে রাঙা দিগন্তের পাশে উপকূলীয় মহাসড়ক ধরে ছুটে চলেছে যাত্রা। সমুদ্রের বাতাস আর গতির ছন্দে ভরে উঠেছে চারপাশ। আজকের বিশ্ব ভ্রমণের শেষ গল্প এখানেই।",
              ),
            "ar" to
              LocalizedStoryContent(
                title = "رحلة الطريق الساحلي",
                description = "مسير سريع على طول الطرق الساحلية المفتوحة عند الغسق.",
                narrationScript =
                  "تمضي القافلة على الطريق الساحلي الممتد بينما يلوّن الغسق الأفق. يمتزج نسيم البحر بانطلاقة الطريق المفتوح في ختام قصص اليوم.",
              ),
            "hi" to
              LocalizedStoryContent(
                title = "तटीय राजमार्ग की दौड़",
                description = "गोधूलि बेला में खुले समुद्र तटीय राजमार्ग पर तेज़ रफ़्तार सफ़र।",
                narrationScript =
                  "समुद्र के किनारे फैले राजमार्ग पर शाम के रंग बिखर रहे हैं। ताज़ी समुद्री हवा और रफ़्तार मिलकर आज की कहानी को यादगार बनाती है।",
              ),
            "zh" to
              LocalizedStoryContent(
                title = "海岸公路疾驰",
                description = "黄昏时分沿着开阔的海岸公路高速驰骋。",
                narrationScript =
                  "暮色染红天际，车队沿着绵延的海岸公路飞驰。海风与自由的速度迎面而来，为今日的全球故事画上精彩句点。",
              ),
            "ru" to
              LocalizedStoryContent(
                title = "Прибрежное шоссе на закате",
                description = "Скоростной пробег вдоль океанского побережья в сумерках.",
                narrationScript =
                  "Моторы ровно гудят на прибрежном шоссе, пока закат окрашивает горизонт. Морской бриз и свобода открытой дороги завершают сегодняшнюю подборку историй.",
              ),
          ),
      ),
    )
}

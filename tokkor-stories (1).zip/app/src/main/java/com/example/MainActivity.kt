package com.example

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.FullScreenStoryPlayerScreen
import com.example.ui.LanguageVoiceStudioSheet
import com.example.ui.StoriesHomeScreen
import com.example.ui.StoriesViewModel
import com.example.ui.theme.TokkorStoriesTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
    )
    setContent {
      TokkorStoriesTheme {
        TokkorStoriesApp()
      }
    }
  }
}

@Composable
fun TokkorStoriesApp(
  viewModel: StoriesViewModel =
    viewModel(
      factory =
        StoriesViewModel.factory(
          LocalContext.current.applicationContext as android.app.Application,
        ),
    ),
) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val lifecycleOwner = LocalLifecycleOwner.current

  DisposableEffect(lifecycleOwner, viewModel) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE -> viewModel.onHostPaused()
        Lifecycle.Event.ON_RESUME -> viewModel.onHostResumed()
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  Box(modifier = Modifier.fillMaxSize()) {
    StoriesHomeScreen(
      uiState = uiState,
      onSelectCategory = viewModel::selectCategory,
      onStoryClick = viewModel::openStory,
      onWatchAllClick = viewModel::openAllStoriesFromStart,
      onOpenLanguageSheet = viewModel::openLanguageSheet,
      onToggleLike = viewModel::toggleLike,
      onToggleSave = viewModel::toggleSave,
    )

    AnimatedVisibility(
      visible = uiState.isPlayerOpen,
      enter = fadeIn() + slideInVertically { it / 8 },
      exit = fadeOut() + slideOutVertically { it / 8 },
    ) {
      val activeIndex = uiState.activePlayerIndex ?: 0
      FullScreenStoryPlayerScreen(
        playlist = uiState.playerPlaylist,
        activeIndex = activeIndex,
        playbackState = uiState.playbackState,
        voiceState = uiState.voiceState,
        isNarrationBarExpanded = uiState.isNarrationBarExpanded,
        player = viewModel.player,
        onSelectIndex = viewModel::selectStoryAtIndex,
        onTogglePlayPause = viewModel::togglePlayPause,
        onSeekTo = viewModel::seekTo,
        onToggleMute = viewModel::toggleMute,
        onNextStory = viewModel::nextStory,
        onPreviousStory = viewModel::previousStory,
        onRetry = viewModel::retryPlayback,
        onToggleLike = viewModel::toggleLike,
        onToggleSave = viewModel::toggleSave,
        onOpenLanguageSheet = viewModel::openLanguageSheet,
        onToggleVoiceNarration = viewModel::toggleVoiceNarration,
        onStopVoiceNarration = viewModel::stopVoiceNarration,
        onToggleNarrationBar = viewModel::toggleNarrationBarExpanded,
        onClose = viewModel::closePlayer,
      )
    }

    if (uiState.isLanguageSheetOpen) {
      LanguageVoiceStudioSheet(
        voiceState = uiState.voiceState,
        activeStoryTitle =
          uiState.activeStory?.localizedTitle(uiState.selectedLanguage.code)
            ?: uiState.stories.firstOrNull()?.localizedTitle(uiState.selectedLanguage.code),
        onSelectLanguage = viewModel::selectLanguage,
        onSelectGender = viewModel::selectVoiceGender,
        onSetSpeed = viewModel::setVoiceSpeed,
        onToggleNarration = viewModel::toggleVoiceNarration,
        onDismiss = viewModel::closeLanguageSheet,
      )
    }
  }
}

package com.example.model

import androidx.annotation.DrawableRes

data class LocalizedStoryContent(
  val title: String,
  val description: String,
  val narrationScript: String,
)

data class Story(
  val id: String,
  val title: String,
  val creatorName: String,
  val creatorHandle: String,
  val category: String,
  val durationLabel: String,
  val videoUrl: String,
  @DrawableRes val posterResId: Int,
  val likesCount: Int,
  val description: String,
  val localizedContent: Map<String, LocalizedStoryContent> = emptyMap(),
  val isLiked: Boolean = false,
  val isSaved: Boolean = false,
) {
  fun localizedTitle(languageCode: String): String =
    localizedContent[languageCode]?.title ?: localizedContent["en"]?.title ?: title

  fun localizedDescription(languageCode: String): String =
    localizedContent[languageCode]?.description ?: localizedContent["en"]?.description ?: description

  fun localizedNarration(languageCode: String): String =
    localizedContent[languageCode]?.narrationScript
      ?: localizedContent["en"]?.narrationScript
      ?: "$title. $description"
}

enum class PlaybackStatus {
  IDLE,
  BUFFERING,
  READY,
  ENDED,
  ERROR,
}

data class PlaybackUiState(
  val status: PlaybackStatus = PlaybackStatus.IDLE,
  val isPlaying: Boolean = false,
  val isMuted: Boolean = false,
  val positionMs: Long = 0L,
  val durationMs: Long = 0L,
  val videoWidth: Int = 0,
  val videoHeight: Int = 0,
  val errorMessage: String? = null,
) {
  val progress: Float
    get() =
      if (durationMs > 0L) {
        (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
      } else {
        0f
      }
}

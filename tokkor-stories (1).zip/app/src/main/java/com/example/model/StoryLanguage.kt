package com.example.model

import java.util.Locale

data class StoryLanguage(
  val code: String,
  val languageTag: String,
  val englishName: String,
  val nativeName: String,
  val flagBadge: String,
  val isRtl: Boolean = false,
  val isPrimary: Boolean = true,
  val isDeviceSupported: Boolean = true,
) {
  val locale: Locale
    get() = Locale.forLanguageTag(languageTag)

  val displayLabel: String
    get() =
      if (nativeName.equals(englishName, ignoreCase = true)) {
        englishName
      } else {
        "$englishName ($nativeName)"
      }
}

enum class VoiceGenderPreference {
  AUTO,
  FEMALE,
  MALE,
}

enum class VoicePlaybackStatus {
  IDLE,
  SPEAKING,
  PAUSED,
  UNSUPPORTED,
  ERROR,
}

data class VoiceUiState(
  val selectedLanguage: StoryLanguage = SupportedStoryLanguages.defaultLanguage,
  val availableLanguages: List<StoryLanguage> = SupportedStoryLanguages.curatedLanguages,
  val genderPreference: VoiceGenderPreference = VoiceGenderPreference.AUTO,
  val speed: Float = 1.0f,
  val status: VoicePlaybackStatus = VoicePlaybackStatus.IDLE,
  val activeVoiceLabel: String? = null,
  val supportsFemaleVoice: Boolean = false,
  val supportsMaleVoice: Boolean = false,
  val currentSegmentIndex: Int = 0,
  val totalSegments: Int = 0,
  val statusMessage: String? = null,
  val isEngineReady: Boolean = false,
) {
  val isSpeaking: Boolean
    get() = status == VoicePlaybackStatus.SPEAKING

  val isPaused: Boolean
    get() = status == VoicePlaybackStatus.PAUSED
}

object SupportedStoryLanguages {
  val Bengali =
    StoryLanguage(
      code = "bn",
      languageTag = "bn-BD",
      englishName = "Bengali",
      nativeName = "বাংলা",
      flagBadge = "BN",
      isRtl = false,
      isPrimary = true,
    )

  val English =
    StoryLanguage(
      code = "en",
      languageTag = "en-US",
      englishName = "English",
      nativeName = "English",
      flagBadge = "EN",
      isRtl = false,
      isPrimary = true,
    )

  val Arabic =
    StoryLanguage(
      code = "ar",
      languageTag = "ar-SA",
      englishName = "Arabic",
      nativeName = "العربية",
      flagBadge = "AR",
      isRtl = true,
      isPrimary = true,
    )

  val Hindi =
    StoryLanguage(
      code = "hi",
      languageTag = "hi-IN",
      englishName = "Hindi",
      nativeName = "हिन्दी",
      flagBadge = "HI",
      isRtl = false,
      isPrimary = true,
    )

  val Chinese =
    StoryLanguage(
      code = "zh",
      languageTag = "zh-CN",
      englishName = "Chinese",
      nativeName = "中文",
      flagBadge = "ZH",
      isRtl = false,
      isPrimary = true,
    )

  val Russian =
    StoryLanguage(
      code = "ru",
      languageTag = "ru-RU",
      englishName = "Russian",
      nativeName = "Русский",
      flagBadge = "RU",
      isRtl = false,
      isPrimary = true,
    )

  val OtherCuratedLanguages: List<StoryLanguage> =
    listOf(
      StoryLanguage("es", "es-ES", "Spanish", "Español", "ES", isRtl = false, isPrimary = false),
      StoryLanguage("fr", "fr-FR", "French", "Français", "FR", isRtl = false, isPrimary = false),
      StoryLanguage("ja", "ja-JP", "Japanese", "日本語", "JA", isRtl = false, isPrimary = false),
      StoryLanguage("ko", "ko-KR", "Korean", "한국어", "KO", isRtl = false, isPrimary = false),
      StoryLanguage("de", "de-DE", "German", "Deutsch", "DE", isRtl = false, isPrimary = false),
      StoryLanguage("pt", "pt-BR", "Portuguese", "Português", "PT", isRtl = false, isPrimary = false),
      StoryLanguage("ur", "ur-PK", "Urdu", "اردو", "UR", isRtl = true, isPrimary = false),
    )

  val PrimaryLanguages: List<StoryLanguage> =
    listOf(Bengali, English, Arabic, Hindi, Chinese, Russian)

  val curatedLanguages: List<StoryLanguage> = PrimaryLanguages + OtherCuratedLanguages

  val defaultLanguage: StoryLanguage = English

  val speedPresets: List<Float> = listOf(0.75f, 1.0f, 1.25f, 1.5f, 1.75f)
}

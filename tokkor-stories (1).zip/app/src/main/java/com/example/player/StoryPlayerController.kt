package com.example.player

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.example.model.PlaybackStatus
import com.example.model.PlaybackUiState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

interface StoryPlayerController {
  val player: Player?
  val playbackState: StateFlow<PlaybackUiState>

  fun loadStory(url: String, autoPlay: Boolean = true)

  fun play()

  fun pause()

  fun togglePlayPause()

  fun seekTo(positionMs: Long)

  fun setMuted(muted: Boolean)

  fun setAudioDucked(ducked: Boolean)

  fun toggleMute()

  fun retry()

  fun stop()

  fun release()
}

@OptIn(UnstableApi::class)
class ExoPlayerStoryController(context: Context) : StoryPlayerController {

  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var progressJob: Job? = null
  private var currentUrl: String? = null

  private val _playbackState = MutableStateFlow(PlaybackUiState())
  override val playbackState: StateFlow<PlaybackUiState> = _playbackState.asStateFlow()

  private val exoPlayer: ExoPlayer =
    ExoPlayer.Builder(context.applicationContext)
      .setAudioAttributes(
        AudioAttributes.Builder()
          .setUsage(C.USAGE_MEDIA)
          .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
          .build(),
        true,
      )
      .setHandleAudioBecomingNoisy(true)
      .build()

  override val player: Player
    get() = exoPlayer

  private val listener =
    object : Player.Listener {
      override fun onPlaybackStateChanged(playbackState: Int) {
        val duration = exoPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0L } ?: 0L
        val currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
        when (playbackState) {
          Player.STATE_IDLE -> {
            _playbackState.update { state ->
              if (state.status == PlaybackStatus.ERROR) state
              else state.copy(status = PlaybackStatus.IDLE, isPlaying = false)
            }
            stopProgressTicker()
          }
          Player.STATE_BUFFERING -> {
            _playbackState.update {
              it.copy(
                status = PlaybackStatus.BUFFERING,
                durationMs = if (duration > 0L) duration else it.durationMs,
                errorMessage = null,
              )
            }
          }
          Player.STATE_READY -> {
            _playbackState.update {
              it.copy(
                status = PlaybackStatus.READY,
                isPlaying = exoPlayer.isPlaying,
                positionMs = currentPos,
                durationMs = duration,
                errorMessage = null,
              )
            }
            if (exoPlayer.isPlaying) {
              startProgressTicker()
            }
          }
          Player.STATE_ENDED -> {
            stopProgressTicker()
            _playbackState.update {
              it.copy(
                status = PlaybackStatus.ENDED,
                isPlaying = false,
                positionMs = duration.takeIf { d -> d > 0L } ?: currentPos,
                durationMs = duration,
              )
            }
          }
        }
      }

      override fun onIsPlayingChanged(isPlaying: Boolean) {
        _playbackState.update { it.copy(isPlaying = isPlaying) }
        if (isPlaying) {
          startProgressTicker()
        } else {
          stopProgressTicker()
        }
      }

      override fun onVideoSizeChanged(videoSize: VideoSize) {
        if (videoSize.width > 0 && videoSize.height > 0) {
          _playbackState.update {
            it.copy(videoWidth = videoSize.width, videoHeight = videoSize.height)
          }
        }
      }

      override fun onPlayerError(error: PlaybackException) {
        stopProgressTicker()
        _playbackState.update {
          it.copy(
            status = PlaybackStatus.ERROR,
            isPlaying = false,
            errorMessage = formatPlaybackError(error),
          )
        }
      }
    }

  init {
    exoPlayer.repeatMode = Player.REPEAT_MODE_OFF
    exoPlayer.addListener(listener)
  }

  override fun loadStory(url: String, autoPlay: Boolean) {
    val trimmedUrl = url.trim()
    currentUrl = trimmedUrl
    stopProgressTicker()

    if (trimmedUrl.isEmpty() || (!trimmedUrl.startsWith("https://") && !trimmedUrl.startsWith("http://"))) {
      exoPlayer.stop()
      _playbackState.update {
        it.copy(
          status = PlaybackStatus.ERROR,
          isPlaying = false,
          positionMs = 0L,
          durationMs = 0L,
          errorMessage = "Invalid video stream URL. Please try the next story.",
        )
      }
      return
    }

    _playbackState.update {
      it.copy(
        status = PlaybackStatus.BUFFERING,
        isPlaying = false,
        positionMs = 0L,
        durationMs = 0L,
        videoWidth = 0,
        videoHeight = 0,
        errorMessage = null,
      )
    }

    val mediaItem = MediaItem.fromUri(Uri.parse(trimmedUrl))
    exoPlayer.setMediaItem(mediaItem)
    exoPlayer.playWhenReady = autoPlay
    exoPlayer.prepare()
  }

  override fun play() {
    if (_playbackState.value.status == PlaybackStatus.ERROR) {
      retry()
      return
    }
    if (exoPlayer.playbackState == Player.STATE_ENDED) {
      exoPlayer.seekTo(0L)
    }
    exoPlayer.playWhenReady = true
    exoPlayer.play()
  }

  override fun pause() {
    exoPlayer.playWhenReady = false
    exoPlayer.pause()
  }

  override fun togglePlayPause() {
    if (exoPlayer.isPlaying) {
      pause()
    } else {
      play()
    }
  }

  override fun seekTo(positionMs: Long) {
    val duration = exoPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0L } ?: 0L
    val clamped = if (duration > 0L) positionMs.coerceIn(0L, duration) else positionMs.coerceAtLeast(0L)
    exoPlayer.seekTo(clamped)
    _playbackState.update { it.copy(positionMs = clamped) }
  }

  private var isDucked = false

  override fun setMuted(muted: Boolean) {
    _playbackState.update { it.copy(isMuted = muted) }
    applyPlayerVolume()
  }

  override fun setAudioDucked(ducked: Boolean) {
    isDucked = ducked
    applyPlayerVolume()
  }

  private fun applyPlayerVolume() {
    exoPlayer.volume =
      when {
        _playbackState.value.isMuted -> 0f
        isDucked -> 0.15f
        else -> 1f
      }
  }

  override fun toggleMute() {
    setMuted(!_playbackState.value.isMuted)
  }

  override fun retry() {
    val url = currentUrl ?: return
    loadStory(url, autoPlay = true)
  }

  override fun stop() {
    stopProgressTicker()
    exoPlayer.stop()
    _playbackState.update {
      it.copy(
        status = PlaybackStatus.IDLE,
        isPlaying = false,
        positionMs = 0L,
        durationMs = 0L,
        errorMessage = null,
      )
    }
  }

  override fun release() {
    stopProgressTicker()
    exoPlayer.removeListener(listener)
    exoPlayer.release()
    scope.cancel()
  }

  private fun startProgressTicker() {
    if (progressJob?.isActive == true) return
    progressJob =
      scope.launch {
        while (isActive) {
          val duration = exoPlayer.duration.takeIf { it != C.TIME_UNSET && it > 0L } ?: 0L
          val position = exoPlayer.currentPosition.coerceAtLeast(0L)
          _playbackState.update {
            it.copy(
              positionMs = position,
              durationMs = if (duration > 0L) duration else it.durationMs,
            )
          }
          delay(120L)
        }
      }
  }

  private fun stopProgressTicker() {
    progressJob?.cancel()
    progressJob = null
  }

  private fun formatPlaybackError(error: PlaybackException): String {
    return when (error.errorCode) {
      PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
      PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
        "Network connection lost. Check your connection and tap Retry."
      PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
      PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
        "This story video couldn't be reached right now (${error.errorCodeName})."
      PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
      PlaybackException.ERROR_CODE_DECODING_FAILED ->
        "Video decoder error on this device. Try skipping to the next story."
      else -> error.localizedMessage ?: "Playback failed (${error.errorCodeName})."
    }
  }
}

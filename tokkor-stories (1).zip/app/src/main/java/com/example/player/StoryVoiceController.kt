package com.example.player

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.example.model.StoryLanguage
import com.example.model.SupportedStoryLanguages
import com.example.model.VoiceGenderPreference
import com.example.model.VoicePlaybackStatus
import com.example.model.VoiceUiState
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

interface StoryVoiceController {
  val voiceState: StateFlow<VoiceUiState>

  fun setLanguage(language: StoryLanguage)

  fun setGenderPreference(gender: VoiceGenderPreference)

  fun setSpeed(speed: Float)

  fun speak(text: String)

  fun pause()

  fun resume()

  fun togglePlayPause(text: String)

  fun stop()

  fun release()
}

class AndroidTtsVoiceController(context: Context) : StoryVoiceController {

  private val appContext = context.applicationContext
  private val _voiceState = MutableStateFlow(VoiceUiState())
  override val voiceState: StateFlow<VoiceUiState> = _voiceState.asStateFlow()

  private var tts: TextToSpeech? = null
  private var isInitialized = false
  private var segments: List<String> = emptyList()
  private var currentSegmentIndex = 0
  private var pendingSpeakText: String? = null
  private var activeRunToken = 0L

  init {
    try {
      tts =
        TextToSpeech(appContext) { status ->
          if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            setupUtteranceListener()
            discoverSupportedLanguages()
            applyLanguageAndVoice(restartIfSpeaking = false)
            pendingSpeakText?.let { queued ->
              pendingSpeakText = null
              speak(queued)
            }
          } else {
            isInitialized = false
            _voiceState.update {
              it.copy(
                isEngineReady = false,
                status = VoicePlaybackStatus.ERROR,
                statusMessage =
                  "Text-to-speech engine could not initialize on this device.",
              )
            }
          }
        }
    } catch (_: Throwable) {
      isInitialized = false
      _voiceState.update {
        it.copy(
          isEngineReady = false,
          status = VoicePlaybackStatus.ERROR,
          statusMessage = "Text-to-speech is unavailable on this device.",
        )
      }
    }
  }

  private fun setupUtteranceListener() {
    tts?.setOnUtteranceProgressListener(
      object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
          val parsed = parseUtteranceId(utteranceId) ?: return
          if (parsed.first != activeRunToken) return
          currentSegmentIndex = parsed.second
          _voiceState.update {
            it.copy(
              status = VoicePlaybackStatus.SPEAKING,
              currentSegmentIndex = parsed.second,
              totalSegments = segments.size,
              statusMessage = null,
            )
          }
        }

        override fun onDone(utteranceId: String?) {
          val parsed = parseUtteranceId(utteranceId) ?: return
          if (parsed.first != activeRunToken) return
          val idx = parsed.second
          if (idx >= segments.lastIndex) {
            currentSegmentIndex = 0
            _voiceState.update {
              it.copy(
                status = VoicePlaybackStatus.IDLE,
                currentSegmentIndex = 0,
              )
            }
          }
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
          handleUtteranceError(utteranceId)
        }

        override fun onError(utteranceId: String?, errorCode: Int) {
          handleUtteranceError(utteranceId)
        }
      }
    )
  }

  private fun handleUtteranceError(utteranceId: String?) {
    val parsed = parseUtteranceId(utteranceId)
    if (parsed != null && parsed.first != activeRunToken) return
    _voiceState.update {
      it.copy(
        status = VoicePlaybackStatus.ERROR,
        statusMessage = "Unable to synthesize speech for the selected voice.",
      )
    }
  }

  private fun discoverSupportedLanguages() {
    val engine = tts ?: return
    val deviceLocales =
      try {
        engine.availableLanguages?.toList().orEmpty()
      } catch (_: Throwable) {
        emptyList()
      }

    val curated =
      SupportedStoryLanguages.curatedLanguages.map { lang ->
        val availability =
          try {
            engine.isLanguageAvailable(lang.locale)
          } catch (_: Throwable) {
            TextToSpeech.LANG_NOT_SUPPORTED
          }
        val supported =
          availability != TextToSpeech.LANG_MISSING_DATA &&
            availability != TextToSpeech.LANG_NOT_SUPPORTED
        lang.copy(isDeviceSupported = supported)
      }

    val curatedCodes = curated.map { it.code }.toSet()
    val extraDeviceLanguages =
      deviceLocales
        .filter { it.language.isNotBlank() && it.language !in curatedCodes }
        .distinctBy { it.language }
        .sortedBy { it.getDisplayLanguage(Locale.ENGLISH) }
        .map { locale ->
          val englishName =
            locale.getDisplayLanguage(Locale.ENGLISH).ifBlank { locale.language.uppercase() }
          val nativeName = locale.getDisplayLanguage(locale).ifBlank { englishName }
          val isRtl = locale.language in setOf("ar", "he", "iw", "fa", "ur")
          StoryLanguage(
            code = locale.language,
            languageTag = locale.toLanguageTag(),
            englishName = englishName,
            nativeName = nativeName,
            flagBadge = locale.language.uppercase().take(2),
            isRtl = isRtl,
            isPrimary = false,
            isDeviceSupported = true,
          )
        }

    _voiceState.update { state ->
      val combined = curated + extraDeviceLanguages
      val refreshedSelected =
        combined.find { it.code == state.selectedLanguage.code } ?: state.selectedLanguage
      state.copy(
        isEngineReady = true,
        availableLanguages = combined,
        selectedLanguage = refreshedSelected,
      )
    }
  }

  override fun setLanguage(language: StoryLanguage) {
    val wasSpeaking = _voiceState.value.status == VoicePlaybackStatus.SPEAKING
    val existingText = segments.joinToString(" ").takeIf { it.isNotBlank() }
    stopInternal(resetProgress = true)
    _voiceState.update { it.copy(selectedLanguage = language, statusMessage = null) }
    applyLanguageAndVoice(restartIfSpeaking = false)
    if (wasSpeaking && existingText != null) {
      speak(existingText)
    }
  }

  override fun setGenderPreference(gender: VoiceGenderPreference) {
    val wasSpeaking = _voiceState.value.status == VoicePlaybackStatus.SPEAKING
    val resumeIndex = currentSegmentIndex
    _voiceState.update { it.copy(genderPreference = gender) }
    applyLanguageAndVoice(restartIfSpeaking = false)
    if (wasSpeaking && segments.isNotEmpty()) {
      speakFromIndex(resumeIndex)
    }
  }

  override fun setSpeed(speed: Float) {
    val clamped = speed.coerceIn(0.5f, 2.0f)
    val wasSpeaking = _voiceState.value.status == VoicePlaybackStatus.SPEAKING
    val resumeIndex = currentSegmentIndex
    tts?.setSpeechRate(clamped)
    _voiceState.update { it.copy(speed = clamped) }
    if (wasSpeaking && segments.isNotEmpty()) {
      speakFromIndex(resumeIndex)
    }
  }

  override fun speak(text: String) {
    val cleaned = text.trim()
    if (cleaned.isEmpty()) return
    segments = splitNarrationSegments(cleaned)
    currentSegmentIndex = 0

    if (!isInitialized) {
      pendingSpeakText = cleaned
      _voiceState.update {
        it.copy(
          totalSegments = segments.size,
          currentSegmentIndex = 0,
          statusMessage = "Preparing voice engine…",
        )
      }
      return
    }

    if (!applyLanguageAndVoice(restartIfSpeaking = false)) {
      return
    }

    speakFromIndex(0)
  }

  override fun pause() {
    if (_voiceState.value.status != VoicePlaybackStatus.SPEAKING) return
    activeRunToken++
    tts?.stop()
    _voiceState.update {
      it.copy(
        status = VoicePlaybackStatus.PAUSED,
        currentSegmentIndex = currentSegmentIndex,
      )
    }
  }

  override fun resume() {
    if (_voiceState.value.status != VoicePlaybackStatus.PAUSED || segments.isEmpty()) return
    if (!applyLanguageAndVoice(restartIfSpeaking = false)) return
    speakFromIndex(currentSegmentIndex)
  }

  override fun togglePlayPause(text: String) {
    when (_voiceState.value.status) {
      VoicePlaybackStatus.SPEAKING -> pause()
      VoicePlaybackStatus.PAUSED -> resume()
      else -> speak(text)
    }
  }

  override fun stop() {
    stopInternal(resetProgress = true)
  }

  override fun release() {
    activeRunToken++
    try {
      tts?.stop()
      tts?.shutdown()
    } catch (_: Throwable) {
    }
    tts = null
    isInitialized = false
  }

  private fun stopInternal(resetProgress: Boolean) {
    activeRunToken++
    try {
      tts?.stop()
    } catch (_: Throwable) {
    }
    if (resetProgress) {
      currentSegmentIndex = 0
    }
    _voiceState.update { state ->
      val nextStatus =
        if (state.status == VoicePlaybackStatus.UNSUPPORTED) {
          VoicePlaybackStatus.UNSUPPORTED
        } else {
          VoicePlaybackStatus.IDLE
        }
      state.copy(
        status = nextStatus,
        currentSegmentIndex = if (resetProgress) 0 else state.currentSegmentIndex,
      )
    }
  }

  private fun speakFromIndex(startIndex: Int) {
    val engine = tts ?: return
    if (segments.isEmpty()) return
    val safeStart = startIndex.coerceIn(0, segments.lastIndex)
    currentSegmentIndex = safeStart
    activeRunToken++
    val token = activeRunToken

    engine.setSpeechRate(_voiceState.value.speed)
    _voiceState.update {
      it.copy(
        status = VoicePlaybackStatus.SPEAKING,
        currentSegmentIndex = safeStart,
        totalSegments = segments.size,
        statusMessage = null,
      )
    }

    for (index in safeStart until segments.size) {
      val queueMode = if (index == safeStart) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
      val utteranceId = "${token}_$index"
      engine.speak(segments[index], queueMode, null, utteranceId)
    }
  }

  private fun applyLanguageAndVoice(restartIfSpeaking: Boolean): Boolean {
    val engine = tts ?: return false
    val lang = _voiceState.value.selectedLanguage
    val availability =
      try {
        engine.isLanguageAvailable(lang.locale)
      } catch (_: Throwable) {
        TextToSpeech.LANG_NOT_SUPPORTED
      }

    if (
      availability == TextToSpeech.LANG_MISSING_DATA ||
        availability == TextToSpeech.LANG_NOT_SUPPORTED
    ) {
      _voiceState.update {
        it.copy(
          status = VoicePlaybackStatus.UNSUPPORTED,
          activeVoiceLabel = null,
          supportsFemaleVoice = false,
          supportsMaleVoice = false,
          statusMessage =
            "Voice data for ${lang.displayLabel} is not installed on this device.",
        )
      }
      return false
    }

    engine.language = lang.locale

    val matchingVoices =
      try {
        engine.voices
          ?.filter { voice ->
            voice.locale.language.equals(lang.locale.language, ignoreCase = true) &&
              !voice.isNetworkConnectionRequired
          }
          ?.ifEmpty {
            engine.voices?.filter { voice ->
              voice.locale.language.equals(lang.locale.language, ignoreCase = true)
            }
          }
          .orEmpty()
      } catch (_: Throwable) {
        emptyList()
      }

    val femaleVoices = matchingVoices.filter { classifyVoiceGender(it) == VoiceGenderPreference.FEMALE }
    val maleVoices = matchingVoices.filter { classifyVoiceGender(it) == VoiceGenderPreference.MALE }

    val selectedVoice: Voice? =
      when (_voiceState.value.genderPreference) {
        VoiceGenderPreference.FEMALE -> femaleVoices.firstOrNull() ?: matchingVoices.firstOrNull()
        VoiceGenderPreference.MALE -> maleVoices.firstOrNull() ?: matchingVoices.firstOrNull()
        VoiceGenderPreference.AUTO ->
          matchingVoices.sortedByDescending { it.quality }.firstOrNull()
      }

    if (selectedVoice != null) {
      try {
        engine.voice = selectedVoice
      } catch (_: Throwable) {
      }
    }

    val voiceLabel =
      when {
        selectedVoice == null -> "${lang.englishName} Default"
        femaleVoices.contains(selectedVoice) -> "${lang.englishName} • Female"
        maleVoices.contains(selectedVoice) -> "${lang.englishName} • Male"
        else -> "${lang.englishName} • Natural"
      }

    _voiceState.update { state ->
      state.copy(
        status =
          if (state.status == VoicePlaybackStatus.UNSUPPORTED) {
            VoicePlaybackStatus.IDLE
          } else {
            state.status
          },
        activeVoiceLabel = voiceLabel,
        supportsFemaleVoice = femaleVoices.isNotEmpty(),
        supportsMaleVoice = maleVoices.isNotEmpty(),
        statusMessage = null,
      )
    }

    if (restartIfSpeaking && _voiceState.value.status == VoicePlaybackStatus.SPEAKING && segments.isNotEmpty()) {
      speakFromIndex(currentSegmentIndex)
    }

    return true
  }

  private fun parseUtteranceId(utteranceId: String?): Pair<Long, Int>? {
    val parts = utteranceId?.split("_") ?: return null
    if (parts.size != 2) return null
    val token = parts[0].toLongOrNull() ?: return null
    val idx = parts[1].toIntOrNull() ?: return null
    return token to idx
  }

  companion object {
    internal fun splitNarrationSegments(text: String): List<String> {
      val raw =
        text
          .split(Regex("(?<=[.!?।。؟\\n])\\s*"))
          .map { it.trim() }
          .filter { it.isNotEmpty() }
      return raw.ifEmpty { listOf(text.trim()) }
    }

    internal fun classifyVoiceGender(voice: Voice): VoiceGenderPreference {
      val name = voice.name.lowercase(Locale.ROOT)
      val featureText = voice.features?.joinToString(" ")?.lowercase(Locale.ROOT).orEmpty()
      val combined = "$name $featureText"
      return when {
        combined.contains("female") ||
          combined.contains("-f-") ||
          combined.contains("_f_") ||
          combined.contains("sfg") ||
          combined.contains("tpf") ||
          combined.contains("x-sfg") ||
          combined.endsWith("-f") -> VoiceGenderPreference.FEMALE
        combined.contains("male") ||
          combined.contains("-m-") ||
          combined.contains("_m_") ||
          combined.contains("smg") ||
          combined.contains("tpm") ||
          combined.contains("x-smg") ||
          combined.endsWith("-m") -> VoiceGenderPreference.MALE
        else -> VoiceGenderPreference.AUTO
      }
    }
  }
}

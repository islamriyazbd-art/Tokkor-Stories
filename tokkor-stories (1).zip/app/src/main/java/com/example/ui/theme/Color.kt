package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0A0918)
val DeepNavyBg = Color(0xFF10122A)
val DarkPurpleSurface = Color(0xFF171332)
val SmokedSurface = Color(0xFF16132E)
val SmokedSurfaceHigh = Color(0xFF221D42)
val CoralPrimary = Color(0xFFFF5A79)
val AmberSecondary = Color(0xFFFFB703)
val GoldHighlight = Color(0xFFFFD166)
val MintTertiary = Color(0xFF2EE6A6)
val AlabasterInk = Color(0xFFF8F7FC)
val LavenderMuted = Color(0xFFB1ACC9)
val OutlineSubtle = Color(0xFF312A54)
val ErrorCrimson = Color(0xFFFF5C77)

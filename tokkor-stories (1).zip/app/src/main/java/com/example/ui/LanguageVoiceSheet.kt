package com.example.ui

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.StoryLanguage
import com.example.model.SupportedStoryLanguages
import com.example.model.VoiceGenderPreference
import com.example.model.VoicePlaybackStatus
import com.example.model.VoiceUiState
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.DeepNavyBg
import com.example.ui.theme.GoldHighlight
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.SmokedSurface
import com.example.ui.theme.SmokedSurfaceHigh
import kotlin.math.roundToInt

@kotlin.OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LanguageVoiceStudioSheet(
  voiceState: VoiceUiState,
  activeStoryTitle: String?,
  onSelectLanguage: (StoryLanguage) -> Unit,
  onSelectGender: (VoiceGenderPreference) -> Unit,
  onSetSpeed: (Float) -> Unit,
  onToggleNarration: () -> Unit,
  onDismiss: () -> Unit,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val context = LocalContext.current

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = SmokedSurface,
    contentColor = MaterialTheme.colorScheme.onSurface,
    modifier = Modifier.testTag("language_voice_sheet"),
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .verticalScroll(rememberScrollState())
          .navigationBarsPadding()
          .padding(horizontal = 20.dp)
          .padding(bottom = 24.dp),
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Box(
            modifier =
              Modifier.size(40.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Brush.linearGradient(listOf(CoralPrimary, AmberSecondary))),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.Language,
              contentDescription = null,
              tint = Color.White,
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = stringResource(R.string.voice_studio_title),
              style = MaterialTheme.typography.titleLarge,
              color = Color.White,
            )
            Text(
              text = stringResource(R.string.voice_studio_subtitle),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
        IconButton(
          onClick = onDismiss,
          modifier = Modifier.minimumInteractiveComponentSize().testTag("close_language_sheet_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = stringResource(R.string.action_close_player),
            tint = Color.White,
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Selected Language Banner
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = DeepNavyBg,
        modifier =
          Modifier.fillMaxWidth()
            .border(1.dp, AmberSecondary.copy(alpha = 0.55f), RoundedCornerShape(18.dp))
            .testTag("selected_language_banner"),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(14.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.voice_selected_language_label),
              style = MaterialTheme.typography.labelSmall,
              color = GoldHighlight,
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = voiceState.selectedLanguage.displayLabel,
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
            )
            val subtitle =
              buildString {
                append(voiceState.activeVoiceLabel ?: "Automatic Voice")
                if (voiceState.selectedLanguage.isRtl) append(" • RTL")
                append(" • ${formatSpeedLabel(voiceState.speed)}")
              }
            Text(
              text = subtitle,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          if (activeStoryTitle != null) {
            Button(
              onClick = onToggleNarration,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("sheet_voice_toggle_button"),
              shape = RoundedCornerShape(50),
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = CoralPrimary,
                  contentColor = Color.White,
                ),
              contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            ) {
              Icon(
                imageVector =
                  if (voiceState.isSpeaking) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text =
                  when (voiceState.status) {
                    VoicePlaybackStatus.SPEAKING -> stringResource(R.string.voice_pause)
                    VoicePlaybackStatus.PAUSED -> stringResource(R.string.voice_resume)
                    else -> stringResource(R.string.voice_play)
                  },
              )
            }
          }
        }
      }

      // Graceful warning if selected language isn't installed on device TTS engine
      if (
        voiceState.status == VoicePlaybackStatus.UNSUPPORTED ||
          voiceState.status == VoicePlaybackStatus.ERROR ||
          !voiceState.selectedLanguage.isDeviceSupported
      ) {
        Spacer(modifier = Modifier.height(12.dp))
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = AmberSecondary.copy(alpha = 0.14f),
          modifier =
            Modifier.fillMaxWidth()
              .border(1.dp, AmberSecondary.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
              .testTag("unsupported_language_banner"),
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Filled.WarningAmber,
                contentDescription = null,
                tint = GoldHighlight,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text =
                  voiceState.statusMessage ?: stringResource(R.string.voice_status_unsupported),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(
              onClick = {
                val intent = Intent("com.android.settings.TTS_SETTINGS")
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                runCatching { context.startActivity(intent) }
              },
              shape = RoundedCornerShape(50),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldHighlight),
            ) {
              Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = stringResource(R.string.voice_open_tts_settings))
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Primary Languages Grid (Bengali, English, Arabic, Hindi, Chinese, Russian)
      Text(
        text = "Primary Languages",
        style = MaterialTheme.typography.titleMedium,
        color = Color.White,
      )
      Spacer(modifier = Modifier.height(10.dp))

      val primaryLanguages = voiceState.availableLanguages.filter { it.isPrimary }
      val otherLanguages = voiceState.availableLanguages.filter { !it.isPrimary }

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        primaryLanguages.chunked(2).forEach { rowItems ->
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            rowItems.forEach { lang ->
              LanguageOptionCard(
                language = lang,
                isSelected = lang.code == voiceState.selectedLanguage.code,
                onClick = { onSelectLanguage(lang) },
                modifier = Modifier.weight(1f),
              )
            }
            if (rowItems.size == 1) {
              Spacer(modifier = Modifier.weight(1f))
            }
          }
        }
      }

      if (otherLanguages.isNotEmpty()) {
        Spacer(modifier = Modifier.height(16.dp))
        Text(
          text = stringResource(R.string.voice_other_languages_label),
          style = MaterialTheme.typography.titleMedium,
          color = Color.White,
        )
        Spacer(modifier = Modifier.height(8.dp))
        FlowRow(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          otherLanguages.forEach { lang ->
            val selected = lang.code == voiceState.selectedLanguage.code
            FilterChip(
              selected = selected,
              onClick = { onSelectLanguage(lang) },
              label = {
                Text(
                  text = "${lang.flagBadge} • ${lang.displayLabel}",
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              },
              modifier = Modifier.testTag("language_option_${lang.code}"),
              shape = RoundedCornerShape(50),
              colors =
                FilterChipDefaults.filterChipColors(
                  containerColor = SmokedSurfaceHigh,
                  labelColor = Color.White,
                  selectedContainerColor = CoralPrimary.copy(alpha = 0.24f),
                  selectedLabelColor = GoldHighlight,
                ),
              border =
                FilterChipDefaults.filterChipBorder(
                  enabled = true,
                  selected = selected,
                  borderColor = OutlineSubtle,
                  selectedBorderColor = AmberSecondary,
                ),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Male & Female Voice Selection
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.RecordVoiceOver,
          contentDescription = null,
          tint = GoldHighlight,
          modifier = Modifier.size(18.dp),
        )
        Text(
          text = stringResource(R.string.voice_gender_label),
          style = MaterialTheme.typography.titleMedium,
          color = Color.White,
        )
      }
      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        val genderOptions =
          listOf(
            VoiceGenderPreference.AUTO to stringResource(R.string.voice_gender_auto),
            VoiceGenderPreference.FEMALE to stringResource(R.string.voice_gender_female),
            VoiceGenderPreference.MALE to stringResource(R.string.voice_gender_male),
          )
        genderOptions.forEach { (pref, label) ->
          val selected = voiceState.genderPreference == pref
          FilterChip(
            selected = selected,
            onClick = { onSelectGender(pref) },
            label = { Text(label) },
            modifier = Modifier.weight(1f).testTag("voice_gender_${pref.name.lowercase()}"),
            shape = RoundedCornerShape(50),
            colors =
              FilterChipDefaults.filterChipColors(
                containerColor = SmokedSurfaceHigh,
                labelColor = Color.White,
                selectedContainerColor = AmberSecondary.copy(alpha = 0.24f),
                selectedLabelColor = GoldHighlight,
              ),
            border =
              FilterChipDefaults.filterChipBorder(
                enabled = true,
                selected = selected,
                borderColor = OutlineSubtle,
                selectedBorderColor = AmberSecondary,
              ),
          )
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Voice Speed Adjustment
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Speed,
            contentDescription = null,
            tint = GoldHighlight,
            modifier = Modifier.size(18.dp),
          )
          Text(
            text = stringResource(R.string.voice_speed_label),
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
          )
        }
        Surface(
          shape = RoundedCornerShape(50),
          color = SmokedSurfaceHigh,
        ) {
          Text(
            text = formatSpeedLabel(voiceState.speed),
            style = MaterialTheme.typography.labelLarge,
            color = GoldHighlight,
            modifier =
              Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                .testTag("voice_speed_value_text"),
          )
        }
      }

      Slider(
        value = voiceState.speed,
        onValueChange = onSetSpeed,
        valueRange = 0.5f..2.0f,
        modifier = Modifier.fillMaxWidth().testTag("voice_speed_slider"),
        colors =
          SliderDefaults.colors(
            thumbColor = GoldHighlight,
            activeTrackColor = CoralPrimary,
            inactiveTrackColor = OutlineSubtle,
          ),
      )

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        SupportedStoryLanguages.speedPresets.forEach { preset ->
          val selected = kotlin.math.abs(voiceState.speed - preset) < 0.05f
          FilterChip(
            selected = selected,
            onClick = { onSetSpeed(preset) },
            label = {
              Text(
                text = formatSpeedLabel(preset),
                style = MaterialTheme.typography.labelSmall,
              )
            },
            modifier = Modifier.weight(1f).testTag("voice_speed_${preset}"),
            shape = RoundedCornerShape(50),
            colors =
              FilterChipDefaults.filterChipColors(
                containerColor = SmokedSurfaceHigh,
                labelColor = Color.White,
                selectedContainerColor = CoralPrimary.copy(alpha = 0.25f),
                selectedLabelColor = Color.White,
              ),
          )
        }
      }
    }
  }
}

@Composable
private fun LanguageOptionCard(
  language: StoryLanguage,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = RoundedCornerShape(16.dp),
    color = if (isSelected) DeepNavyBg else SmokedSurfaceHigh,
    modifier =
      modifier
        .clip(RoundedCornerShape(16.dp))
        .border(
          width = if (isSelected) 1.5.dp else 1.dp,
          color = if (isSelected) AmberSecondary else OutlineSubtle,
          shape = RoundedCornerShape(16.dp),
        )
        .clickable(onClick = onClick)
        .testTag("language_option_${language.code}"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f),
      ) {
        Box(
          modifier =
            Modifier.size(32.dp)
              .clip(CircleShape)
              .background(
                if (isSelected) {
                  Brush.linearGradient(listOf(CoralPrimary, AmberSecondary))
                } else {
                  Brush.linearGradient(listOf(OutlineSubtle, OutlineSubtle))
                }
              ),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = language.flagBadge,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = language.nativeName,
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text =
              if (language.isRtl) "${language.englishName} • RTL" else language.englishName,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      if (isSelected) {
        Icon(
          imageVector = Icons.Filled.CheckCircle,
          contentDescription = null,
          tint = GoldHighlight,
          modifier = Modifier.size(18.dp),
        )
      } else if (!language.isDeviceSupported) {
        Icon(
          imageVector = Icons.Filled.GraphicEq,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
          modifier = Modifier.size(16.dp),
        )
      }
    }
  }
}

internal fun formatSpeedLabel(speed: Float): String {
  val rounded = (speed * 100f).roundToInt() / 100f
  return if (rounded % 1f == 0f) {
    "${rounded.toInt()}.0x"
  } else {
    "${rounded}x"
  }
}

package com.example.ui

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import com.example.data.StoryRepository
import com.example.model.PlaybackStatus
import com.example.model.PlaybackUiState
import com.example.model.Story
import com.example.model.StoryLanguage
import com.example.model.VoiceGenderPreference
import com.example.model.VoicePlaybackStatus
import com.example.model.VoiceUiState
import com.example.player.AndroidTtsVoiceController
import com.example.player.ExoPlayerStoryController
import com.example.player.StoryPlayerController
import com.example.player.StoryVoiceController
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class StoriesUiState(
  val stories: List<Story> = emptyList(),
  val selectedCategory: String = "All",
  val activePlayerIndex: Int? = null,
  val playerPlaylist: List<Story> = emptyList(),
  val playbackState: PlaybackUiState = PlaybackUiState(),
  val voiceState: VoiceUiState = VoiceUiState(),
  val isLanguageSheetOpen: Boolean = false,
  val isNarrationBarExpanded: Boolean = true,
) {
  val categories: List<String>
    get() = listOf("All") + stories.map { it.category }.distinct()

  val filteredStories: List<Story>
    get() =
      if (selectedCategory == "All") {
        stories
      } else {
        stories.filter { it.category == selectedCategory }
      }

  val activeStory: Story?
    get() = activePlayerIndex?.let { idx -> playerPlaylist.getOrNull(idx) }

  val isPlayerOpen: Boolean
    get() = activePlayerIndex != null && activeStory != null

  val hasNextStory: Boolean
    get() = activePlayerIndex != null && activePlayerIndex < playerPlaylist.lastIndex

  val hasPreviousStory: Boolean
    get() = activePlayerIndex != null && activePlayerIndex > 0

  val selectedLanguage: StoryLanguage
    get() = voiceState.selectedLanguage
}

class StoriesViewModel(
  private val playerController: StoryPlayerController,
  initialStories: List<Story> = StoryRepository.getStories(),
  private val voiceController: StoryVoiceController = NoOpStoryVoiceController(),
) : ViewModel() {

  private val _uiState =
    MutableStateFlow(
      StoriesUiState(
        stories = initialStories,
        playerPlaylist = initialStories,
        voiceState = voiceController.voiceState.value,
      )
    )
  val uiState: StateFlow<StoriesUiState> = _uiState.asStateFlow()

  val player: Player?
    get() = playerController.player

  private var resumeVideoOnForeground = false
  private var resumeVoiceOnForeground = false
  private var lastHandledEndedStoryId: String? = null

  init {
    viewModelScope.launch {
      playerController.playbackState.collect { playback ->
        _uiState.update { it.copy(playbackState = playback) }
        val state = _uiState.value
        val activeStory = state.activeStory
        if (
          playback.status == PlaybackStatus.ENDED &&
            state.isPlayerOpen &&
            activeStory != null &&
            lastHandledEndedStoryId != activeStory.id
        ) {
          lastHandledEndedStoryId = activeStory.id
          if (state.hasNextStory) {
            nextStory()
          }
        }
      }
    }

    viewModelScope.launch {
      voiceController.voiceState.collect { voice ->
        _uiState.update { it.copy(voiceState = voice) }
        playerController.setAudioDucked(voice.isSpeaking)
      }
    }
  }

  fun selectCategory(category: String) {
    _uiState.update { it.copy(selectedCategory = category) }
  }

  fun openStory(story: Story) {
    val currentStories = _uiState.value.stories
    val playlist =
      if (_uiState.value.selectedCategory == "All") {
        currentStories
      } else {
        _uiState.value.filteredStories.ifEmpty { currentStories }
      }
    val targetIndex = playlist.indexOfFirst { it.id == story.id }.coerceAtLeast(0)
    openPlaylistAt(playlist, targetIndex)
  }

  fun openAllStoriesFromStart() {
    val playlist = _uiState.value.filteredStories.ifEmpty { _uiState.value.stories }
    if (playlist.isNotEmpty()) {
      openPlaylistAt(playlist, 0)
    }
  }

  fun selectStoryAtIndex(index: Int) {
    val state = _uiState.value
    if (index !in state.playerPlaylist.indices) return
    if (state.activePlayerIndex == index) return
    val story = state.playerPlaylist[index]
    val wasVoiceSpeaking = state.voiceState.isSpeaking
    lastHandledEndedStoryId = null
    _uiState.update { it.copy(activePlayerIndex = index) }
    playerController.loadStory(story.videoUrl, autoPlay = true)
    if (wasVoiceSpeaking) {
      voiceController.speak(story.localizedNarration(state.selectedLanguage.code))
    } else {
      voiceController.stop()
    }
  }

  private fun openPlaylistAt(playlist: List<Story>, index: Int) {
    if (index !in playlist.indices) return
    val story = playlist[index]
    lastHandledEndedStoryId = null
    voiceController.stop()
    _uiState.update {
      it.copy(
        playerPlaylist = playlist,
        activePlayerIndex = index,
      )
    }
    playerController.loadStory(story.videoUrl, autoPlay = true)
  }

  fun closePlayer() {
    resumeVideoOnForeground = false
    resumeVoiceOnForeground = false
    lastHandledEndedStoryId = null
    voiceController.stop()
    playerController.setAudioDucked(false)
    playerController.stop()
    _uiState.update { it.copy(activePlayerIndex = null) }
  }

  fun togglePlayPause() {
    if (_uiState.value.playbackState.status == PlaybackStatus.ENDED) {
      lastHandledEndedStoryId = null
    }
    playerController.togglePlayPause()
  }

  fun play() {
    playerController.play()
  }

  fun pause() {
    playerController.pause()
  }

  fun seekTo(positionMs: Long) {
    playerController.seekTo(positionMs)
  }

  fun toggleMute() {
    playerController.toggleMute()
  }

  fun nextStory() {
    val state = _uiState.value
    val currentIndex = state.activePlayerIndex ?: return
    if (currentIndex < state.playerPlaylist.lastIndex) {
      selectStoryAtIndex(currentIndex + 1)
    }
  }

  fun previousStory() {
    val state = _uiState.value
    val currentIndex = state.activePlayerIndex ?: return
    if (currentIndex > 0) {
      selectStoryAtIndex(currentIndex - 1)
    }
  }

  fun retryPlayback() {
    lastHandledEndedStoryId = null
    playerController.retry()
  }

  // Multilingual Voice Controls
  fun openLanguageSheet() {
    _uiState.update { it.copy(isLanguageSheetOpen = true) }
  }

  fun closeLanguageSheet() {
    _uiState.update { it.copy(isLanguageSheetOpen = false) }
  }

  fun toggleNarrationBarExpanded() {
    _uiState.update { it.copy(isNarrationBarExpanded = !it.isNarrationBarExpanded) }
  }

  fun selectLanguage(language: StoryLanguage) {
    val state = _uiState.value
    val activeStory = state.activeStory
    val wasSpeaking = state.voiceState.isSpeaking
    voiceController.setLanguage(language)
    if (wasSpeaking && activeStory != null) {
      voiceController.speak(activeStory.localizedNarration(language.code))
    }
  }

  fun selectVoiceGender(gender: VoiceGenderPreference) {
    voiceController.setGenderPreference(gender)
  }

  fun setVoiceSpeed(speed: Float) {
    voiceController.setSpeed(speed)
  }

  fun toggleVoiceNarration() {
    val state = _uiState.value
    val story = state.activeStory ?: state.stories.firstOrNull() ?: return
    val script = story.localizedNarration(state.selectedLanguage.code)
    voiceController.togglePlayPause(script)
  }

  fun speakStory(story: Story) {
    val script = story.localizedNarration(_uiState.value.selectedLanguage.code)
    voiceController.speak(script)
  }

  fun pauseVoiceNarration() {
    voiceController.pause()
  }

  fun resumeVoiceNarration() {
    voiceController.resume()
  }

  fun stopVoiceNarration() {
    voiceController.stop()
  }

  fun toggleLike(storyId: String) {
    _uiState.update { state ->
      val updatedStories =
        state.stories.map { story ->
          if (story.id == storyId) {
            val liked = !story.isLiked
            story.copy(
              isLiked = liked,
              likesCount =
                if (liked) story.likesCount + 1 else (story.likesCount - 1).coerceAtLeast(0),
            )
          } else {
            story
          }
        }
      val updatedPlaylist =
        state.playerPlaylist.map { pStory ->
          updatedStories.find { it.id == pStory.id } ?: pStory
        }
      state.copy(stories = updatedStories, playerPlaylist = updatedPlaylist)
    }
  }

  fun toggleSave(storyId: String) {
    _uiState.update { state ->
      val updatedStories =
        state.stories.map { story ->
          if (story.id == storyId) story.copy(isSaved = !story.isSaved) else story
        }
      val updatedPlaylist =
        state.playerPlaylist.map { pStory ->
          updatedStories.find { it.id == pStory.id } ?: pStory
        }
      state.copy(stories = updatedStories, playerPlaylist = updatedPlaylist)
    }
  }

  fun onHostPaused() {
    if (_uiState.value.isPlayerOpen && _uiState.value.playbackState.isPlaying) {
      resumeVideoOnForeground = true
      playerController.pause()
    }
    if (_uiState.value.voiceState.isSpeaking) {
      resumeVoiceOnForeground = true
      voiceController.pause()
    }
  }

  fun onHostResumed() {
    if (_uiState.value.isPlayerOpen && resumeVideoOnForeground) {
      resumeVideoOnForeground = false
      playerController.play()
    }
    if (resumeVoiceOnForeground) {
      resumeVoiceOnForeground = false
      voiceController.resume()
    }
  }

  override fun onCleared() {
    super.onCleared()
    playerController.release()
    voiceController.release()
  }

  companion object {
    fun factory(application: Application): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return StoriesViewModel(
            playerController = ExoPlayerStoryController(application),
            voiceController = AndroidTtsVoiceController(application),
          ) as T
        }
      }
  }
}

private class NoOpStoryVoiceController : StoryVoiceController {
  private val state = MutableStateFlow(VoiceUiState(status = VoicePlaybackStatus.IDLE))
  override val voiceState: StateFlow<VoiceUiState> = state.asStateFlow()

  override fun setLanguage(language: StoryLanguage) {
    state.update { it.copy(selectedLanguage = language) }
  }

  override fun setGenderPreference(gender: VoiceGenderPreference) {
    state.update { it.copy(genderPreference = gender) }
  }

  override fun setSpeed(speed: Float) {
    state.update { it.copy(speed = speed) }
  }

  override fun speak(text: String) {
    state.update { it.copy(status = VoicePlaybackStatus.SPEAKING) }
  }

  override fun pause() {
    state.update { it.copy(status = VoicePlaybackStatus.PAUSED) }
  }

  override fun resume() {
    state.update { it.copy(status = VoicePlaybackStatus.SPEAKING) }
  }

  override fun togglePlayPause(text: String) {
    when (state.value.status) {
      VoicePlaybackStatus.SPEAKING -> pause()
      VoicePlaybackStatus.PAUSED -> resume()
      else -> speak(text)
    }
  }

  override fun stop() {
    state.update { it.copy(status = VoicePlaybackStatus.IDLE) }
  }

  override fun release() = Unit
}

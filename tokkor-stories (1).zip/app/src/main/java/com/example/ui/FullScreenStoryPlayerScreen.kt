package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.compose.PlayerSurface
import androidx.media3.ui.compose.SURFACE_TYPE_TEXTURE_VIEW
import com.example.R
import com.example.model.PlaybackStatus
import com.example.model.PlaybackUiState
import com.example.model.Story
import com.example.model.VoicePlaybackStatus
import com.example.model.VoiceUiState
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.DeepNavyBg
import com.example.ui.theme.ErrorCrimson
import com.example.ui.theme.GoldHighlight
import com.example.ui.theme.SmokedSurface
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged

@OptIn(UnstableApi::class)
@Composable
fun FullScreenStoryPlayerScreen(
  playlist: List<Story>,
  activeIndex: Int,
  playbackState: PlaybackUiState,
  voiceState: VoiceUiState,
  isNarrationBarExpanded: Boolean,
  player: Player?,
  onSelectIndex: (Int) -> Unit,
  onTogglePlayPause: () -> Unit,
  onSeekTo: (Long) -> Unit,
  onToggleMute: () -> Unit,
  onNextStory: () -> Unit,
  onPreviousStory: () -> Unit,
  onRetry: () -> Unit,
  onToggleLike: (String) -> Unit,
  onToggleSave: (String) -> Unit,
  onOpenLanguageSheet: () -> Unit,
  onToggleVoiceNarration: () -> Unit,
  onStopVoiceNarration: () -> Unit,
  onToggleNarrationBar: () -> Unit,
  onClose: () -> Unit,
  modifier: Modifier = Modifier,
) {
  if (playlist.isEmpty()) return

  val safeIndex = activeIndex.coerceIn(0, playlist.lastIndex)
  val pagerState =
    rememberPagerState(
      initialPage = safeIndex,
      pageCount = { playlist.size },
    )

  BackHandler { onClose() }

  // Sync ViewModel index changes (Next/Prev buttons or auto-advance) -> VerticalPager
  LaunchedEffect(safeIndex) {
    if (pagerState.currentPage != safeIndex) {
      pagerState.animateScrollToPage(safeIndex)
    }
  }

  // Sync user vertical swipe -> ViewModel
  LaunchedEffect(pagerState) {
    snapshotFlow { pagerState.settledPage }
      .distinctUntilChanged()
      .collect { settled ->
        if (settled != activeIndex) {
          onSelectIndex(settled)
        }
      }
  }

  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(Color.Black)
        .testTag("fullscreen_story_player"),
  ) {
    VerticalPager(
      state = pagerState,
      modifier = Modifier.fillMaxSize().testTag("story_vertical_pager"),
      key = { index -> playlist[index].id },
    ) { pageIndex ->
      val story = playlist[pageIndex]
      val isCurrentPage = pageIndex == safeIndex

      StoryPlayerPage(
        story = story,
        pageIndex = pageIndex,
        totalCount = playlist.size,
        isCurrentPage = isCurrentPage,
        playbackState = if (isCurrentPage) playbackState else PlaybackUiState(),
        voiceState = voiceState,
        isNarrationBarExpanded = isNarrationBarExpanded,
        player = if (isCurrentPage) player else null,
        hasPrevious = pageIndex > 0,
        hasNext = pageIndex < playlist.lastIndex,
        onTogglePlayPause = onTogglePlayPause,
        onSeekTo = onSeekTo,
        onToggleMute = onToggleMute,
        onNextStory = onNextStory,
        onPreviousStory = onPreviousStory,
        onRetry = onRetry,
        onToggleLike = { onToggleLike(story.id) },
        onToggleSave = { onToggleSave(story.id) },
        onOpenLanguageSheet = onOpenLanguageSheet,
        onToggleVoiceNarration = onToggleVoiceNarration,
        onStopVoiceNarration = onStopVoiceNarration,
        onToggleNarrationBar = onToggleNarrationBar,
        onClose = onClose,
      )
    }
  }
}

@OptIn(UnstableApi::class)
@Composable
private fun StoryPlayerPage(
  story: Story,
  pageIndex: Int,
  totalCount: Int,
  isCurrentPage: Boolean,
  playbackState: PlaybackUiState,
  voiceState: VoiceUiState,
  isNarrationBarExpanded: Boolean,
  player: Player?,
  hasPrevious: Boolean,
  hasNext: Boolean,
  onTogglePlayPause: () -> Unit,
  onSeekTo: (Long) -> Unit,
  onToggleMute: () -> Unit,
  onNextStory: () -> Unit,
  onPreviousStory: () -> Unit,
  onRetry: () -> Unit,
  onToggleLike: () -> Unit,
  onToggleSave: () -> Unit,
  onOpenLanguageSheet: () -> Unit,
  onToggleVoiceNarration: () -> Unit,
  onStopVoiceNarration: () -> Unit,
  onToggleNarrationBar: () -> Unit,
  onClose: () -> Unit,
) {
  var showTapFeedback by remember(story.id) { mutableStateOf(false) }

  LaunchedEffect(showTapFeedback) {
    if (showTapFeedback) {
      delay(650L)
      showTapFeedback = false
    }
  }

  val tapInteractionSource = remember { MutableInteractionSource() }
  val selectedLang = voiceState.selectedLanguage
  val localizedTitle = story.localizedTitle(selectedLang.code)
  val localizedDescription = story.localizedDescription(selectedLang.code)
  val localizedNarration = story.localizedNarration(selectedLang.code)
  val storyLayoutDirection = if (selectedLang.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

  Box(
    modifier = Modifier.fillMaxSize().background(Color.Black),
  ) {
    // Poster fallback layer prevents black flash while preparing or when switching pages
    Image(
      painter = painterResource(id = story.posterResId),
      contentDescription = localizedTitle,
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )

    // Real Media3 video rendering surface when attached to active page
    if (isCurrentPage && player != null) {
      val videoAspectRatio =
        if (playbackState.videoWidth > 0 && playbackState.videoHeight > 0) {
          (playbackState.videoWidth.toFloat() / playbackState.videoHeight.toFloat())
            .coerceIn(0.45f, 2.2f)
        } else {
          null
        }

      Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center,
      ) {
        PlayerSurface(
          player = player,
          surfaceType = SURFACE_TYPE_TEXTURE_VIEW,
          modifier =
            if (videoAspectRatio != null) {
              Modifier.fillMaxWidth().aspectRatio(videoAspectRatio)
            } else {
              Modifier.fillMaxSize()
            },
        )
      }

      // Keep poster visible while buffering first frame before video size arrives
      if (playbackState.videoWidth == 0 && playbackState.status == PlaybackStatus.BUFFERING) {
        Image(
          painter = painterResource(id = story.posterResId),
          contentDescription = null,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
      }
    }

    // Dedicated tap layer for play/pause behind HUD overlays so HUD semantics aren't merged
    Box(
      modifier =
        Modifier.fillMaxSize()
          .clickable(
            interactionSource = tapInteractionSource,
            indication = null,
          ) {
            if (playbackState.status != PlaybackStatus.ERROR) {
              onTogglePlayPause()
              showTapFeedback = true
            }
          },
    )

    // Top & bottom atmospheric legibility scrims
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(190.dp)
          .align(Alignment.TopCenter)
          .background(
            Brush.verticalGradient(
              colors = listOf(Color.Black.copy(alpha = 0.82f), Color.Transparent),
            )
          ),
    )

    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(340.dp)
          .align(Alignment.BottomCenter)
          .background(
            Brush.verticalGradient(
              colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.94f)),
            )
          ),
    )

    // Top bar: segmented progress + creator header + language chip + counter + mute + close
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .align(Alignment.TopCenter)
          .statusBarsPadding()
          .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
      StorySegmentedProgressBar(
        totalCount = totalCount,
        currentIndex = pageIndex,
        activeProgress = if (isCurrentPage) playbackState.progress else 0f,
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f),
        ) {
          Image(
            painter = painterResource(id = story.posterResId),
            contentDescription = story.creatorName,
            contentScale = ContentScale.Crop,
            modifier =
              Modifier.size(38.dp)
                .clip(CircleShape)
                .border(1.5.dp, GoldHighlight, CircleShape),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = story.creatorName,
              style = MaterialTheme.typography.titleMedium,
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = story.creatorHandle,
              style = MaterialTheme.typography.labelSmall,
              color = Color.White.copy(alpha = 0.78f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          Surface(
            shape = RoundedCornerShape(50),
            color = Color.Black.copy(alpha = 0.55f),
            modifier = Modifier.border(1.dp, Color.White.copy(alpha = 0.22f), RoundedCornerShape(50)),
          ) {
            Text(
              text = "${pageIndex + 1} / $totalCount",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
              softWrap = false,
              modifier =
                Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                  .testTag("story_counter_text"),
            )
          }

          IconButton(
            onClick = onToggleMute,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("mute_button"),
          ) {
            Icon(
              imageVector =
                if (playbackState.isMuted) {
                  Icons.AutoMirrored.Filled.VolumeOff
                } else {
                  Icons.AutoMirrored.Filled.VolumeUp
                },
              contentDescription =
                if (playbackState.isMuted) {
                  stringResource(R.string.action_unmute)
                } else {
                  stringResource(R.string.action_mute)
                },
              tint = Color.White,
            )
          }

          IconButton(
            onClick = onClose,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("close_player_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = stringResource(R.string.action_close_player),
              tint = Color.White,
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Clean second-row international language pill so top bar never cramps on narrow phones
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start,
      ) {
        Surface(
          onClick = onOpenLanguageSheet,
          shape = RoundedCornerShape(50),
          color = DeepNavyBg.copy(alpha = 0.85f),
          modifier =
            Modifier.border(1.dp, AmberSecondary.copy(alpha = 0.65f), RoundedCornerShape(50))
              .testTag("player_language_chip"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Language,
              contentDescription = stringResource(R.string.action_select_language),
              tint = GoldHighlight,
              modifier = Modifier.size(14.dp),
            )
            Text(
              text = "${selectedLang.flagBadge} • ${selectedLang.displayLabel}",
              style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
              color = Color.White,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }

    // Bottom Area: Localized Story Info + Side Navigation/Social Rail + Voice Narration Bar + Playback Bar
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .align(Alignment.BottomCenter)
          .navigationBarsPadding()
          .padding(horizontal = 14.dp, vertical = 10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        // Localized Story Title & Description (RTL-aware for Arabic)
        CompositionLocalProvider(LocalLayoutDirection provides storyLayoutDirection) {
          Column(
            modifier = Modifier.weight(1f).padding(end = 12.dp),
          ) {
            Surface(
              shape = RoundedCornerShape(50),
              color = CoralPrimary.copy(alpha = 0.24f),
              modifier =
                Modifier.border(1.dp, CoralPrimary.copy(alpha = 0.5f), RoundedCornerShape(50)),
            ) {
              Text(
                text = story.category,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = CoralPrimary,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
              )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = localizedTitle,
              style = MaterialTheme.typography.titleLarge,
              color = Color.White,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.testTag("player_story_title"),
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = localizedDescription,
              style = MaterialTheme.typography.bodyMedium,
              color = Color.White.copy(alpha = 0.85f),
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        // Right-hand quick vertical navigation & engagement rail
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          IconButton(
            onClick = onPreviousStory,
            enabled = hasPrevious,
            modifier =
              Modifier.size(48.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = if (hasPrevious) 0.55f else 0.25f))
                .testTag("previous_video_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.KeyboardArrowUp,
              contentDescription = stringResource(R.string.action_previous),
              tint = if (hasPrevious) Color.White else Color.White.copy(alpha = 0.35f),
              modifier = Modifier.size(26.dp),
            )
          }

          IconButton(
            onClick = onNextStory,
            enabled = hasNext,
            modifier =
              Modifier.size(48.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = if (hasNext) 0.55f else 0.25f))
                .testTag("next_video_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.KeyboardArrowDown,
              contentDescription = stringResource(R.string.action_next),
              tint = if (hasNext) Color.White else Color.White.copy(alpha = 0.35f),
              modifier = Modifier.size(26.dp),
            )
          }

          IconButton(
            onClick = onToggleNarrationBar,
            modifier =
              Modifier.size(48.dp)
                .clip(CircleShape)
                .background(
                  if (voiceState.isSpeaking) {
                    AmberSecondary.copy(alpha = 0.85f)
                  } else {
                    Color.Black.copy(alpha = 0.50f)
                  }
                )
                .testTag("voice_narration_toggle_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.RecordVoiceOver,
              contentDescription = stringResource(R.string.voice_narration_title),
              tint = if (voiceState.isSpeaking) Color.Black else GoldHighlight,
            )
          }

          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(
              onClick = onToggleLike,
              modifier =
                Modifier.size(48.dp)
                  .clip(CircleShape)
                  .background(Color.Black.copy(alpha = 0.45f))
                  .testTag("like_story_button"),
            ) {
              Icon(
                imageVector =
                  if (story.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = stringResource(R.string.action_like),
                tint = if (story.isLiked) CoralPrimary else Color.White,
              )
            }
            Text(
              text = formatCount(story.likesCount),
              style = MaterialTheme.typography.labelSmall,
              color = Color.White,
            )
          }

          IconButton(
            onClick = onToggleSave,
            modifier =
              Modifier.size(48.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.45f))
                .testTag("save_story_button"),
          ) {
            Icon(
              imageVector =
                if (story.isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
              contentDescription = stringResource(R.string.action_bookmark),
              tint = if (story.isSaved) AmberSecondary else Color.White,
            )
          }
        }
      }

      // Multilingual TTS Voice Narration Panel
      AnimatedVisibility(visible = isCurrentPage && isNarrationBarExpanded) {
        Column {
          Spacer(modifier = Modifier.height(6.dp))
          Surface(
            shape = RoundedCornerShape(16.dp),
            color = DeepNavyBg.copy(alpha = 0.90f),
            modifier =
              Modifier.fillMaxWidth()
                .border(1.dp, AmberSecondary.copy(alpha = 0.45f), RoundedCornerShape(16.dp))
                .testTag("voice_narration_panel"),
          ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  modifier = Modifier.weight(1f),
                ) {
                  IconButton(
                    onClick = onToggleVoiceNarration,
                    modifier =
                      Modifier.size(48.dp)
                        .clip(CircleShape)
                        .background(CoralPrimary)
                        .testTag("voice_play_pause_button"),
                  ) {
                    Icon(
                      imageVector =
                        if (voiceState.isSpeaking) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                      contentDescription =
                        when (voiceState.status) {
                          VoicePlaybackStatus.SPEAKING -> stringResource(R.string.voice_pause)
                          VoicePlaybackStatus.PAUSED -> stringResource(R.string.voice_resume)
                          else -> stringResource(R.string.voice_play)
                        },
                      tint = Color.White,
                    )
                  }

                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text =
                        when (voiceState.status) {
                          VoicePlaybackStatus.SPEAKING -> stringResource(R.string.voice_status_speaking)
                          VoicePlaybackStatus.PAUSED -> stringResource(R.string.voice_status_paused)
                          VoicePlaybackStatus.UNSUPPORTED -> "Voice Pack Missing"
                          VoicePlaybackStatus.ERROR -> "Voice Unavailable"
                          VoicePlaybackStatus.IDLE -> stringResource(R.string.voice_narration_title)
                        },
                      style = MaterialTheme.typography.labelLarge,
                      color = GoldHighlight,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text =
                        "${selectedLang.displayLabel} • ${voiceState.activeVoiceLabel ?: voiceState.genderPreference.name}",
                      style = MaterialTheme.typography.labelSmall,
                      color = Color.White.copy(alpha = 0.78f),
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                }

                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  if (voiceState.isSpeaking || voiceState.isPaused) {
                    IconButton(
                      onClick = onStopVoiceNarration,
                      modifier =
                        Modifier.minimumInteractiveComponentSize()
                          .testTag("voice_stop_button"),
                    ) {
                      Icon(
                        imageVector = Icons.Filled.Stop,
                        contentDescription = stringResource(R.string.voice_stop),
                        tint = Color.White,
                      )
                    }
                  }

                  Surface(
                    onClick = onOpenLanguageSheet,
                    shape = RoundedCornerShape(50),
                    color = SmokedSurface,
                    modifier =
                      Modifier.minimumInteractiveComponentSize()
                        .border(1.dp, GoldHighlight.copy(alpha = 0.4f), RoundedCornerShape(50))
                        .testTag("voice_speed_button"),
                  ) {
                    Text(
                      text = formatSpeedLabel(voiceState.speed),
                      style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                      color = GoldHighlight,
                      modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(4.dp))

              CompositionLocalProvider(LocalLayoutDirection provides storyLayoutDirection) {
                Text(
                  text = localizedNarration,
                  style = MaterialTheme.typography.bodyMedium,
                  color = Color.White.copy(alpha = 0.92f),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.fillMaxWidth().testTag("narration_localized_text"),
                )
              }

              if (
                voiceState.status == VoicePlaybackStatus.UNSUPPORTED ||
                  voiceState.status == VoicePlaybackStatus.ERROR
              ) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text =
                    voiceState.statusMessage ?: stringResource(R.string.voice_status_unsupported),
                  style = MaterialTheme.typography.labelSmall,
                  color = GoldHighlight,
                  modifier = Modifier.testTag("player_voice_unsupported_badge"),
                )
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Bottom Video Playback Control Bar (Play/Pause, Previous, Seek Bar, Next)
      Surface(
        shape = RoundedCornerShape(18.dp),
        color = Color.Black.copy(alpha = 0.65f),
        modifier =
          Modifier.fillMaxWidth()
            .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(18.dp)),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(
            onClick = onPreviousStory,
            enabled = hasPrevious,
            modifier =
              Modifier.minimumInteractiveComponentSize().testTag("controls_previous_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.SkipPrevious,
              contentDescription = stringResource(R.string.action_previous),
              tint = if (hasPrevious) Color.White else Color.White.copy(alpha = 0.35f),
            )
          }

          IconButton(
            onClick = onTogglePlayPause,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("play_pause_button"),
          ) {
            Icon(
              imageVector =
                if (playbackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
              contentDescription =
                if (playbackState.isPlaying) {
                  stringResource(R.string.action_pause)
                } else {
                  stringResource(R.string.action_play)
                },
              tint = CoralPrimary,
              modifier = Modifier.size(28.dp),
            )
          }

          IconButton(
            onClick = onNextStory,
            enabled = hasNext,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("controls_next_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.SkipNext,
              contentDescription = stringResource(R.string.action_next),
              tint = if (hasNext) Color.White else Color.White.copy(alpha = 0.35f),
            )
          }

          var isScrubbing by remember(story.id) { mutableStateOf(false) }
          var scrubPosition by remember(story.id) { mutableFloatStateOf(0f) }
          val sliderValue = if (isScrubbing) scrubPosition else playbackState.progress

          Slider(
            value = sliderValue,
            onValueChange = { value ->
              isScrubbing = true
              scrubPosition = value
            },
            onValueChangeFinished = {
              isScrubbing = false
              if (playbackState.durationMs > 0L) {
                onSeekTo((scrubPosition * playbackState.durationMs).toLong())
              }
            },
            enabled = isCurrentPage && playbackState.durationMs > 0L,
            modifier = Modifier.weight(1f).testTag("video_seek_slider"),
            colors =
              SliderDefaults.colors(
                thumbColor = GoldHighlight,
                activeTrackColor = CoralPrimary,
                inactiveTrackColor = Color.White.copy(alpha = 0.25f),
              ),
          )

          Text(
            text = "${formatTimeMs(playbackState.positionMs)} / ${formatTimeMs(playbackState.durationMs)}",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.9f),
            modifier = Modifier.padding(horizontal = 8.dp).testTag("video_time_text"),
          )
        }
      }
    }

    // Center Buffering / Loading Indicator (above HUD layers)
    if (isCurrentPage && playbackState.status == PlaybackStatus.BUFFERING) {
      Surface(
        modifier = Modifier.align(Alignment.Center).testTag("video_loading_indicator"),
        shape = RoundedCornerShape(20.dp),
        color = Color.Black.copy(alpha = 0.78f),
      ) {
        Column(
          modifier = Modifier.padding(horizontal = 24.dp, vertical = 18.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          CircularProgressIndicator(
            color = GoldHighlight,
            trackColor = Color.White.copy(alpha = 0.2f),
            strokeWidth = 3.5.dp,
            modifier = Modifier.size(38.dp),
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = stringResource(R.string.status_buffering),
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
          )
        }
      }
    }

    // Center Paused / Tap-burst Play-Pause Indicator
    val showPausedOverlay =
      isCurrentPage &&
        playbackState.status == PlaybackStatus.READY &&
        !playbackState.isPlaying
    AnimatedVisibility(
      visible = showPausedOverlay || (isCurrentPage && showTapFeedback && playbackState.status != PlaybackStatus.ERROR),
      enter = fadeIn() + scaleIn(initialScale = 0.85f),
      exit = fadeOut() + scaleOut(targetScale = 0.85f),
      modifier = Modifier.align(Alignment.Center),
    ) {
      Surface(
        onClick = onTogglePlayPause,
        shape = CircleShape,
        color = Color.Black.copy(alpha = 0.65f),
        modifier =
          Modifier.size(72.dp)
            .border(1.5.dp, GoldHighlight.copy(alpha = 0.75f), CircleShape)
            .testTag("center_play_pause_indicator"),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector =
              if (playbackState.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
            contentDescription =
              if (playbackState.isPlaying) {
                stringResource(R.string.action_pause)
              } else {
                stringResource(R.string.action_play)
              },
            tint = Color.White,
            modifier = Modifier.size(38.dp),
          )
        }
      }
    }

    // Center Error Handling Overlay (highest Z-order so Retry / Skip Next are always clickable)
    if (isCurrentPage && playbackState.status == PlaybackStatus.ERROR) {
      Surface(
        modifier =
          Modifier.align(Alignment.Center)
            .padding(horizontal = 24.dp)
            .widthIn(max = 400.dp)
            .testTag("video_error_overlay"),
        shape = RoundedCornerShape(24.dp),
        color = SmokedSurface.copy(alpha = 0.96f),
        tonalElevation = 8.dp,
      ) {
        Column(
          modifier = Modifier.padding(24.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier =
              Modifier.size(56.dp)
                .clip(CircleShape)
                .background(ErrorCrimson.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.ErrorOutline,
              contentDescription = null,
              tint = ErrorCrimson,
              modifier = Modifier.size(30.dp),
            )
          }
          Spacer(modifier = Modifier.height(14.dp))
          Text(
            text = stringResource(R.string.error_video_title),
            style = MaterialTheme.typography.titleLarge,
            color = Color.White,
            textAlign = TextAlign.Center,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = playbackState.errorMessage ?: stringResource(R.string.error_video_network),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
          )
          Spacer(modifier = Modifier.height(18.dp))
          Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Button(
              onClick = onRetry,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("retry_video_button"),
              shape = RoundedCornerShape(50),
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = CoralPrimary,
                  contentColor = Color.White,
                ),
            ) {
              Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(text = stringResource(R.string.action_retry))
            }

            if (hasNext) {
              OutlinedButton(
                onClick = onNextStory,
                modifier =
                  Modifier.minimumInteractiveComponentSize().testTag("error_next_button"),
                shape = RoundedCornerShape(50),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
              ) {
                Text(text = stringResource(R.string.action_skip_next))
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StorySegmentedProgressBar(
  totalCount: Int,
  currentIndex: Int,
  activeProgress: Float,
) {
  Row(
    modifier = Modifier.fillMaxWidth().testTag("story_progress_segments"),
    horizontalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    repeat(totalCount) { index ->
      val segmentFill =
        when {
          index < currentIndex -> 1f
          index == currentIndex -> activeProgress.coerceIn(0f, 1f)
          else -> 0f
        }
      Box(
        modifier =
          Modifier.weight(1f)
            .height(3.dp)
            .clip(RoundedCornerShape(50))
            .background(Color.White.copy(alpha = 0.28f)),
      ) {
        if (segmentFill > 0f) {
          Box(
            modifier =
              Modifier.fillMaxHeight()
                .fillMaxWidth(segmentFill)
                .background(
                  Brush.horizontalGradient(listOf(CoralPrimary, AmberSecondary)),
                ),
          )
        }
      }
    }
  }
}

internal fun formatTimeMs(ms: Long): String {
  if (ms <= 0L) return "0:00"
  val totalSeconds = ms / 1000L
  val minutes = totalSeconds / 60L
  val seconds = totalSeconds % 60L
  return String.format("%d:%02d", minutes, seconds)
}

package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TokkorDarkColorScheme =
  darkColorScheme(
    primary = CoralPrimary,
    onPrimary = Color.White,
    secondary = AmberSecondary,
    onSecondary = Color.Black,
    tertiary = MintTertiary,
    background = ObsidianBg,
    onBackground = AlabasterInk,
    surface = SmokedSurface,
    onSurface = AlabasterInk,
    surfaceVariant = SmokedSurfaceHigh,
    onSurfaceVariant = LavenderMuted,
    outline = OutlineSubtle,
    error = ErrorCrimson,
    onError = Color.White,
  )

@Composable
fun TokkorStoriesTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = TokkorDarkColorScheme,
    typography = TokkorTypography,
    content = content,
  )
}

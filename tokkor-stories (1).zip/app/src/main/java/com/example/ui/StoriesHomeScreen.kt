package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.Story
import com.example.model.StoryLanguage
import com.example.model.VoiceUiState
import com.example.ui.theme.AmberSecondary
import com.example.ui.theme.CoralPrimary
import com.example.ui.theme.DeepNavyBg
import com.example.ui.theme.GoldHighlight
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.OutlineSubtle
import com.example.ui.theme.SmokedSurface
import com.example.ui.theme.SmokedSurfaceHigh

@Composable
fun StoriesHomeScreen(
  uiState: StoriesUiState,
  onSelectCategory: (String) -> Unit,
  onStoryClick: (Story) -> Unit,
  onWatchAllClick: () -> Unit,
  onOpenLanguageSheet: () -> Unit,
  onToggleLike: (String) -> Unit,
  onToggleSave: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val selectedLanguage = uiState.selectedLanguage

  Scaffold(
    modifier =
      modifier
        .fillMaxSize()
        .background(Brush.verticalGradient(listOf(ObsidianBg, DeepNavyBg))),
    containerColor = Color.Transparent,
    topBar = {
      TokkorTopBar(
        selectedLanguage = selectedLanguage,
        onWatchAllClick = onWatchAllClick,
        onOpenLanguageSheet = onOpenLanguageSheet,
      )
    },
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 165.dp),
        modifier = Modifier.fillMaxSize().widthIn(max = 1000.dp).testTag("stories_grid"),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
          InternationalVoiceBanner(
            voiceState = uiState.voiceState,
            onOpenLanguageSheet = onOpenLanguageSheet,
          )
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
          StoryRingsRow(
            stories = uiState.stories,
            selectedLanguage = selectedLanguage,
            onStoryClick = onStoryClick,
          )
        }

        item(span = { GridItemSpan(maxLineSpan) }) {
          CategoryFilterRow(
            categories = uiState.categories,
            selectedCategory = uiState.selectedCategory,
            onSelectCategory = onSelectCategory,
          )
        }

        items(
          items = uiState.filteredStories,
          key = { it.id },
        ) { story ->
          StoryFeedCard(
            story = story,
            selectedLanguage = selectedLanguage,
            onClick = { onStoryClick(story) },
            onToggleLike = { onToggleLike(story.id) },
            onToggleSave = { onToggleSave(story.id) },
          )
        }
      }
    }
  }
}

@Composable
private fun TokkorTopBar(
  selectedLanguage: StoryLanguage,
  onWatchAllClick: () -> Unit,
  onOpenLanguageSheet: () -> Unit,
) {
  Row(
    modifier =
      Modifier.fillMaxWidth()
        .background(
          Brush.verticalGradient(
            colors = listOf(ObsidianBg, ObsidianBg.copy(alpha = 0.94f)),
          )
        )
        .statusBarsPadding()
        .padding(horizontal = 16.dp, vertical = 12.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.weight(1f),
    ) {
      Image(
        painter = painterResource(id = R.drawable.ic_tokkor_cinematic_fg),
        contentDescription = stringResource(R.string.app_name),
        contentScale = ContentScale.Crop,
        modifier =
          Modifier.size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, AmberSecondary.copy(alpha = 0.65f), RoundedCornerShape(12.dp)),
      )
      Column {
        Text(
          text = stringResource(R.string.app_name),
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = stringResource(R.string.stories_feed_subtitle),
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }

    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Surface(
        onClick = onOpenLanguageSheet,
        shape = RoundedCornerShape(50),
        color = SmokedSurfaceHigh,
        modifier =
          Modifier.minimumInteractiveComponentSize()
            .border(1.dp, AmberSecondary.copy(alpha = 0.55f), RoundedCornerShape(50))
            .testTag("language_selector_button"),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Language,
            contentDescription = stringResource(R.string.action_select_language),
            tint = GoldHighlight,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = selectedLanguage.flagBadge,
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
          )
          Icon(
            imageVector = Icons.Filled.KeyboardArrowDown,
            contentDescription = null,
            tint = GoldHighlight,
            modifier = Modifier.size(16.dp),
          )
        }
      }

      Button(
        onClick = onWatchAllClick,
        modifier = Modifier.minimumInteractiveComponentSize().testTag("watch_stories_button"),
        shape = RoundedCornerShape(50),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = CoralPrimary,
            contentColor = Color.White,
          ),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.PlayArrow,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = stringResource(R.string.action_watch_all),
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }
}

@Composable
private fun InternationalVoiceBanner(
  voiceState: VoiceUiState,
  onOpenLanguageSheet: () -> Unit,
) {
  Surface(
    onClick = onOpenLanguageSheet,
    shape = RoundedCornerShape(18.dp),
    color = SmokedSurface,
    modifier =
      Modifier.fillMaxWidth()
        .border(
          width = 1.dp,
          brush = Brush.horizontalGradient(listOf(OutlineSubtle, AmberSecondary.copy(alpha = 0.55f))),
          shape = RoundedCornerShape(18.dp),
        )
        .testTag("voice_settings_button"),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.weight(1f),
      ) {
        Box(
          modifier =
            Modifier.size(36.dp)
              .clip(CircleShape)
              .background(
                Brush.linearGradient(listOf(DeepNavyBg, AmberSecondary.copy(alpha = 0.35f))),
              )
              .border(1.dp, AmberSecondary.copy(alpha = 0.6f), CircleShape),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.RecordVoiceOver,
            contentDescription = null,
            tint = GoldHighlight,
            modifier = Modifier.size(18.dp),
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = "${stringResource(R.string.voice_selected_language_label)}: ${voiceState.selectedLanguage.displayLabel}",
            style = MaterialTheme.typography.labelLarge,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.testTag("home_selected_language_text"),
          )
          val voiceMeta =
            buildString {
              append(voiceState.activeVoiceLabel ?: voiceState.genderPreference.name.lowercase().replaceFirstChar { it.uppercase() })
              append(" • ${formatSpeedLabel(voiceState.speed)}")
              if (voiceState.selectedLanguage.isRtl) append(" • RTL")
            }
          Text(
            text = voiceMeta,
            style = MaterialTheme.typography.labelSmall,
            color = GoldHighlight.copy(alpha = 0.9f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      Surface(
        shape = RoundedCornerShape(50),
        color = SmokedSurfaceHigh,
      ) {
        Text(
          text = "Voice",
          style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
          color = GoldHighlight,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
        )
      }
    }
  }
}

@Composable
private fun StoryRingsRow(
  stories: List<Story>,
  selectedLanguage: StoryLanguage,
  onStoryClick: (Story) -> Unit,
) {
  Column(modifier = Modifier.fillMaxWidth()) {
    LazyRow(
      modifier = Modifier.fillMaxWidth().testTag("story_rings_row"),
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      contentPadding = PaddingValues(vertical = 8.dp),
    ) {
      items(stories, key = { "ring_${it.id}" }) { story ->
        val localizedTitle = story.localizedTitle(selectedLanguage.code)
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier =
            Modifier.width(74.dp)
              .clip(RoundedCornerShape(14.dp))
              .clickable { onStoryClick(story) }
              .padding(vertical = 4.dp)
              .testTag("story_ring_${story.id}"),
        ) {
          Box(
            modifier =
              Modifier.size(66.dp)
                .border(
                  width = 2.5.dp,
                  brush = Brush.linearGradient(listOf(CoralPrimary, AmberSecondary)),
                  shape = CircleShape,
                )
                .padding(4.dp)
                .clip(CircleShape)
                .background(SmokedSurfaceHigh),
            contentAlignment = Alignment.Center,
          ) {
            Image(
              painter = painterResource(id = story.posterResId),
              contentDescription = "${story.creatorName}: $localizedTitle",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize().clip(CircleShape),
            )
            Box(
              modifier =
                Modifier.size(22.dp)
                  .align(Alignment.BottomEnd)
                  .clip(CircleShape)
                  .background(ObsidianBg.copy(alpha = 0.85f)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.PlayArrow,
                contentDescription = null,
                tint = GoldHighlight,
                modifier = Modifier.size(14.dp),
              )
            }
          }
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = story.creatorName.substringBefore(" "),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onBackground,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
  }
}

@Composable
private fun CategoryFilterRow(
  categories: List<String>,
  selectedCategory: String,
  onSelectCategory: (String) -> Unit,
) {
  LazyRow(
    modifier = Modifier.fillMaxWidth().testTag("category_filter_row"),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
  ) {
    items(categories, key = { it }) { category ->
      val selected = category == selectedCategory
      FilterChip(
        selected = selected,
        onClick = { onSelectCategory(category) },
        label = {
          Text(
            text = category,
            style = MaterialTheme.typography.labelLarge,
          )
        },
        modifier = Modifier.testTag("category_chip_$category"),
        shape = RoundedCornerShape(50),
        colors =
          FilterChipDefaults.filterChipColors(
            containerColor = SmokedSurface,
            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
            selectedContainerColor = CoralPrimary.copy(alpha = 0.2f),
            selectedLabelColor = GoldHighlight,
          ),
        border =
          FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = OutlineSubtle,
            selectedBorderColor = AmberSecondary,
          ),
      )
    }
  }
}

@Composable
private fun StoryFeedCard(
  story: Story,
  selectedLanguage: StoryLanguage,
  onClick: () -> Unit,
  onToggleLike: () -> Unit,
  onToggleSave: () -> Unit,
) {
  val localizedTitle = story.localizedTitle(selectedLanguage.code)
  val layoutDirection = if (selectedLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .aspectRatio(9f / 14f)
        .clip(RoundedCornerShape(20.dp))
        .border(1.dp, OutlineSubtle, RoundedCornerShape(20.dp))
        .clickable(onClick = onClick)
        .testTag("story_card_${story.id}"),
    shape = RoundedCornerShape(20.dp),
    color = SmokedSurface,
  ) {
    Box(modifier = Modifier.fillMaxSize()) {
      Image(
        painter = painterResource(id = story.posterResId),
        contentDescription = localizedTitle,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )

      Box(
        modifier =
          Modifier.fillMaxSize()
            .background(
              Brush.verticalGradient(
                colors =
                  listOf(
                    Color.Black.copy(alpha = 0.45f),
                    Color.Transparent,
                    Color.Black.copy(alpha = 0.90f),
                  ),
              )
            )
      )

      // Top pills
      Row(
        modifier = Modifier.fillMaxWidth().padding(10.dp).align(Alignment.TopCenter),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Surface(
          shape = RoundedCornerShape(50),
          color = Color.Black.copy(alpha = 0.55f),
        ) {
          Text(
            text = story.category,
            style = MaterialTheme.typography.labelSmall,
            color = Color.White,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }

        Surface(
          shape = RoundedCornerShape(50),
          color = CoralPrimary.copy(alpha = 0.92f),
        ) {
          Text(
            text = story.durationLabel,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
      }

      // Center play affordance
      Box(
        modifier =
          Modifier.size(50.dp)
            .align(Alignment.Center)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.48f))
            .border(1.5.dp, GoldHighlight.copy(alpha = 0.85f), CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.PlayArrow,
          contentDescription = stringResource(R.string.action_play),
          tint = Color.White,
          modifier = Modifier.size(28.dp),
        )
      }

      // Bottom localized metadata and actions
      CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Column(
          modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(12.dp),
        ) {
          Text(
            text = localizedTitle,
            style = MaterialTheme.typography.titleMedium,
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = story.creatorHandle,
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.78f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = onToggleLike,
                modifier = Modifier.size(48.dp).testTag("feed_like_${story.id}"),
              ) {
                Icon(
                  imageVector =
                    if (story.isLiked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                  contentDescription = stringResource(R.string.action_like),
                  tint = if (story.isLiked) CoralPrimary else Color.White,
                  modifier = Modifier.size(18.dp),
                )
              }
              Text(
                text = formatCount(story.likesCount),
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.9f),
              )
            }

            IconButton(
              onClick = onToggleSave,
              modifier = Modifier.size(48.dp).testTag("feed_save_${story.id}"),
            ) {
              Icon(
                imageVector =
                  if (story.isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                contentDescription = stringResource(R.string.action_bookmark),
                tint = if (story.isSaved) AmberSecondary else Color.White,
                modifier = Modifier.size(18.dp),
              )
            }
          }
        }
      }
    }
  }
}

internal fun formatCount(count: Int): String =
  if (count >= 1000) {
    String.format("%.1fk", count / 1000f)
  } else {
    count.toString()
  }
